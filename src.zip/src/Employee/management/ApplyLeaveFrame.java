package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class ApplyLeaveFrame extends JFrame implements ActionListener {

    Integer employeeId;          // null or -1 in admin mode
    boolean adminMode;

    JComboBox<String> leaveTypeCombo;
    JTextField tStartDate, tEndDate;
    JTextArea tReason;
    JButton btnApply, btnClear, btnClose;

    JComboBox<String> empSelector;   // 🔹 used only in adminMode

    // 🔹 Employee mode constructor
    public ApplyLeaveFrame(int employeeId) {
        this.employeeId = employeeId;
        this.adminMode = false;
        initUI();
    }

    // 🔹 Admin mode constructor (no employeeId passed)
    public ApplyLeaveFrame() {
        this.employeeId = null;
        this.adminMode = true;
        initUI();
    }

    private void initUI() {
        setTitle(adminMode ? "Apply Leave (Admin Mode)" : "Apply for Leave");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        // Header
        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 520, 70);
        header.setLayout(null);

        JLabel heading = new JLabel(adminMode ? "Apply Leave (Admin)" : "Apply Leave");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(170, 20, 250, 30);
        header.add(heading);
        add(header);

        int y = 90;

        if (adminMode) {
            JLabel lEmp = new JLabel("Select Employee:");
            lEmp.setBounds(40, y, 120, 25);
            add(lEmp);

            empSelector = new JComboBox<>();
            empSelector.setBounds(160, y, 260, 25);
            add(empSelector);

            y += 40; // push rest down

            // load employees into dropdown
            loadEmployeeDropdown();
        }

        // Leave Type
        JLabel l1 = new JLabel("Leave Type:");
        l1.setBounds(40, y, 120, 25);
        add(l1);

        leaveTypeCombo = new JComboBox<>(new String[]{
                "Sick Leave", "Casual Leave", "Earned Leave", "Unpaid Leave"
        });
        leaveTypeCombo.setBounds(160, y, 260, 25);
        add(leaveTypeCombo);

        y += 40;

        // Start Date
        JLabel l2 = new JLabel("Start Date (yyyy-MM-dd):");
        l2.setBounds(40, y, 200, 25);
        add(l2);

        tStartDate = new JTextField(LocalDate.now().toString());
        tStartDate.setBounds(240, y, 180, 25);
        add(tStartDate);

        y += 40;

        // End Date
        JLabel l3 = new JLabel("End Date (yyyy-MM-dd):");
        l3.setBounds(40, y, 200, 25);
        add(l3);

        tEndDate = new JTextField(LocalDate.now().plusDays(1).toString());
        tEndDate.setBounds(240, y, 180, 25);
        add(tEndDate);

        y += 40;

        // Reason
        JLabel l4 = new JLabel("Reason:");
        l4.setBounds(40, y, 120, 25);
        add(l4);

        tReason = new JTextArea();
        JScrollPane sp = new JScrollPane(tReason);
        sp.setBounds(160, y, 260, 80);
        add(sp);

        y += 100;

        // Buttons
        btnApply = createButton("Apply");
        btnApply.setBounds(60, y, 120, 30);
        btnApply.addActionListener(this);
        add(btnApply);

        btnClear = createButton("Clear");
        btnClear.setBounds(200, y, 120, 30);
        btnClear.addActionListener(e -> clearForm());
        add(btnClear);

        btnClose = createButton("Close");
        btnClose.setBounds(340, y, 120, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        // Frame settings
        setSize(520, y + 100);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        applyLeave();
    }

    private void applyLeave() {
        Integer finalEmployeeId = employeeId;

        // In admin mode, override with selected employee
        if (adminMode) {
            Object sel = empSelector.getSelectedItem();
            if (sel == null || "Select Employee".equals(sel.toString())) {
                JOptionPane.showMessageDialog(this, "Please select an employee");
                return;
            }
            String[] parts = sel.toString().split(" - ");
            try {
                finalEmployeeId = Integer.parseInt(parts[0].trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid selected employee");
                return;
            }
        }

        if (finalEmployeeId == null || finalEmployeeId <= 0) {
            JOptionPane.showMessageDialog(this, "Invalid employee");
            return;
        }

        String leaveType = leaveTypeCombo.getSelectedItem().toString();
        String startDate = tStartDate.getText().trim();
        String endDate = tEndDate.getText().trim();
        String reason = tReason.getText().trim();

        if (startDate.isEmpty() || endDate.isEmpty() || reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.");
            return;
        }

        try {
            LocalDate s = LocalDate.parse(startDate);
            LocalDate e = LocalDate.parse(endDate);
            if (e.isBefore(s)) {
                JOptionPane.showMessageDialog(this, "End date cannot be before start date.");
                return;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format (use yyyy-MM-dd)");
            return;
        }

        String sql = "INSERT INTO leave_applications " +
                "(employee_id, leave_type, start_date, end_date, reason, status) " +
                "VALUES (?, ?, ?, ?, ?, 'PENDING')";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, finalEmployeeId);
            ps.setString(2, leaveType);
            ps.setString(3, startDate);
            ps.setString(4, endDate);
            ps.setString(5, reason);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Leave applied successfully!");

            clearForm();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error applying leave: " + ex.getMessage());
        }
    }

    private void clearForm() {
        leaveTypeCombo.setSelectedIndex(0);
        tStartDate.setText(LocalDate.now().toString());
        tEndDate.setText(LocalDate.now().plusDays(1).toString());
        tReason.setText("");
        if (adminMode && empSelector != null) {
            empSelector.setSelectedIndex(0);
        }
    }
}
