package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeIdCardFrame extends JFrame implements ActionListener {

    JComboBox<String> empSelector;
    JTextArea idArea;
    JButton btnGenerate, btnPrint, btnClose;

    public EmployeeIdCardFrame() {
        setTitle("Employee ID Card");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JLabel lEmp = new JLabel("Select Employee:");
        lEmp.setBounds(30, 20, 120, 25);
        add(lEmp);

        empSelector = new JComboBox<>();
        empSelector.setBounds(150, 20, 260, 25);
        add(empSelector);

        btnGenerate = new JButton("Generate ID");
        btnGenerate.setBounds(420, 20, 120, 25);
        btnGenerate.setBackground(new Color(25, 118, 210));
        btnGenerate.setForeground(Color.WHITE);
        btnGenerate.addActionListener(this);
        add(btnGenerate);

        idArea = new JTextArea();
        idArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane sp = new JScrollPane(idArea);
        sp.setBounds(30, 60, 510, 200);
        add(sp);

        btnPrint = new JButton("Print");
        btnPrint.setBounds(150, 280, 100, 30);
        btnPrint.setBackground(new Color(25, 118, 210));
        btnPrint.setForeground(Color.WHITE);
        btnPrint.addActionListener(e -> printId());
        add(btnPrint);

        btnClose = new JButton("Close");
        btnClose.setBounds(280, 280, 100, 30);
        btnClose.setBackground(new Color(25, 118, 210));
        btnClose.setForeground(Color.WHITE);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(580, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployeeDropdown();
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private Integer getSelectedEmployeeId() {
        Object sel = empSelector.getSelectedItem();
        if (sel == null) return null;
        String s = sel.toString();
        if (s.startsWith("Select")) return null;
        String[] parts = s.split(" - ");
        try { return Integer.parseInt(parts[0].trim()); } catch (Exception e) { return null; }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        generateCard();
    }

    private void generateCard() {
        Integer id = getSelectedEmployeeId();
        if (id == null) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        String sql = "SELECT emp_code, name, department, designation FROM employees WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String empCode = rs.getString("emp_code");
                String name = rs.getString("name");
                String dept = rs.getString("department");
                String desig = rs.getString("designation");

                StringBuilder sb = new StringBuilder();
                sb.append("=====================================\n");
                sb.append("           COMPANY NAME HERE         \n");
                sb.append("            EMPLOYEE ID CARD         \n");
                sb.append("=====================================\n");
                sb.append("Emp Code : ").append(empCode).append("\n");
                sb.append("Name     : ").append(name).append("\n");
                sb.append("Dept     : ").append(dept).append("\n");
                sb.append("Desig    : ").append(desig).append("\n");
                sb.append("=====================================\n");
                sb.append("Authorized Sign.\n");
                sb.append("=====================================\n");

                idArea.setText(sb.toString());
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void printId() {
        try {
            idArea.print();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error printing: " + e.getMessage());
        }
    }
}
