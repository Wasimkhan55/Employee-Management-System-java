package Employee.management;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.io.*;

public class ExportUtils {

    public static void exportTableToCSV(JTable table, JFrame parent) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save as CSV (open in Excel)");
        int result = chooser.showSaveDialog(parent);
        if (result != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getAbsolutePath() + ".csv");
        }

        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            TableModel model = table.getModel();

            // header
            for (int i = 0; i < model.getColumnCount(); i++) {
                pw.print(model.getColumnName(i));
                if (i < model.getColumnCount() - 1) pw.print(",");
            }
            pw.println();

            // rows
            for (int r = 0; r < model.getRowCount(); r++) {
                for (int c = 0; c < model.getColumnCount(); c++) {
                    Object val = model.getValueAt(r, c);
                    pw.print(val != null ? val.toString() : "");
                    if (c < model.getColumnCount() - 1) pw.print(",");
                }
                pw.println();
            }

            pw.flush();
            JOptionPane.showMessageDialog(parent, "Exported successfully:\n" + file.getAbsolutePath());

        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Error exporting: " + ex.getMessage());
        }
    }
}
