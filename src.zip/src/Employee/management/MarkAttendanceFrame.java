package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class MarkAttendanceFrame extends JFrame implements ActionListener {

    JComboBox<String> empSelector;   // "id - EMP0001 - Name"
    JTextField tDate, tCheckIn, tCheckOut;
    JComboBox<String> statusCombo;
    JButton btnSave, btnClear, btnClose;

    public MarkAttendanceFrame() {
        setTitle("Mark Attendance");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 500, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Mark Employee Attendance");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 18));
        heading.setBounds(100, 20, 300, 30);
        header.add(heading);
        add(header);

        // 🔹 Employee dropdown (no manual emp code)
        JLabel lEmpSelect = new JLabel("Select Emp:");
        lEmpSelect.setBounds(40, 90, 100, 25);
        add(lEmpSelect);

        empSelector = new JComboBox<>();
        empSelector.setBounds(150, 90, 260, 25);
        add(empSelector);

        JLabel lDate = new JLabel("Date (yyyy-MM-dd):");
        lDate.setBounds(40, 130, 140, 25);
        add(lDate);

        tDate = new JTextField(LocalDate.now().toString());
        tDate.setBounds(190, 130, 180, 25);
        add(tDate);

        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(40, 170, 100, 25);
        add(lStatus);

        statusCombo = new JComboBox<>(new String[]{"PRESENT", "ABSENT", "LEAVE"});
        statusCombo.setBounds(150, 170, 200, 25);
        add(statusCombo);

        JLabel lCheckIn = new JLabel("Check In (HH:mm:ss):");
        lCheckIn.setBounds(40, 210, 140, 25);
        add(lCheckIn);

        tCheckIn = new JTextField("09:00:00");
        tCheckIn.setBounds(190, 210, 160, 25);
        add(tCheckIn);

        JLabel lCheckOut = new JLabel("Check Out (HH:mm:ss):");
        lCheckOut.setBounds(40, 250, 140, 25);
        add(lCheckOut);

        tCheckOut = new JTextField("17:00:00");
        tCheckOut.setBounds(190, 250, 160, 25);
        add(tCheckOut);

        btnSave = createButton("Save / Update");
        btnSave.setBounds(40, 300, 140, 30);
        btnSave.addActionListener(this);
        add(btnSave);

        btnClear = createButton("Clear");
        btnClear.setBounds(190, 300, 90, 30);
        btnClear.addActionListener(e -> clearForm());
        add(btnClear);

        btnClose = createButton("Close");
        btnClose.setBounds(290, 300, 90, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(500, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // Load employees in dropdown
        loadEmployeeDropdown();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String code = rs.getString("emp_code");
                String name = rs.getString("name");
                empSelector.addItem(id + " - " + code + " - " + name);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    private Integer getSelectedEmployeeId() {
        Object sel = empSelector.getSelectedItem();
        if (sel == null) return null;
        String s = sel.toString();
        if (s.startsWith("Select")) return null;

        String[] parts = s.split(" - ");
        if (parts.length < 1) return null;

        try {
            return Integer.parseInt(parts[0].trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        saveAttendance();
    }

    private void saveAttendance() {
        Integer employeeId = getSelectedEmployeeId();
        if (employeeId == null) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        String dateStr = tDate.getText().trim();
        String status = statusCombo.getSelectedItem().toString();
        String checkInStr = tCheckIn.getText().trim();
        String checkOutStr = tCheckOut.getText().trim();

        if (dateStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Date is required");
            return;
        }

        try {
            LocalDate.parse(dateStr);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format (yyyy-MM-dd)");
            return;
        }

        java.sql.Time checkInTime = null;
        java.sql.Time checkOutTime = null;
        try {
            if (!checkInStr.isEmpty())
                checkInTime = java.sql.Time.valueOf(checkInStr);
            if (!checkOutStr.isEmpty())
                checkOutTime = java.sql.Time.valueOf(checkOutStr);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Invalid time format (HH:mm:ss)");
            return;
        }

        String sqlCheck = "SELECT id FROM attendance WHERE employee_id=? AND date=?";
        String sqlInsert = "INSERT INTO attendance (employee_id, date, status, check_in, check_out) VALUES (?, ?, ?, ?, ?)";
        String sqlUpdate = "UPDATE attendance SET status=?, check_in=?, check_out=? WHERE id=?";

        try (Connection con = conn.getConnection()) {

            int attendanceId = -1;
            try (PreparedStatement psCheck = con.prepareStatement(sqlCheck)) {
                psCheck.setInt(1, employeeId);
                psCheck.setString(2, dateStr);
                ResultSet rsCheck = psCheck.executeQuery();
                if (rsCheck.next()) {
                    attendanceId = rsCheck.getInt("id");
                }
            }

            if (attendanceId == -1) {
                try (PreparedStatement psIns = con.prepareStatement(sqlInsert)) {
                    psIns.setInt(1, employeeId);
                    psIns.setString(2, dateStr);
                    psIns.setString(3, status);
                    if (checkInTime != null) psIns.setTime(4, checkInTime); else psIns.setNull(4, java.sql.Types.TIME);
                    if (checkOutTime != null) psIns.setTime(5, checkOutTime); else psIns.setNull(5, java.sql.Types.TIME);
                    psIns.executeUpdate();
                }
                JOptionPane.showMessageDialog(this, "Attendance marked (inserted)");
            } else {
                try (PreparedStatement psUpd = con.prepareStatement(sqlUpdate)) {
                    psUpd.setString(1, status);
                    if (checkInTime != null) psUpd.setTime(2, checkInTime); else psUpd.setNull(2, java.sql.Types.TIME);
                    if (checkOutTime != null) psUpd.setTime(3, checkOutTime); else psUpd.setNull(3, java.sql.Types.TIME);
                    psUpd.setInt(4, attendanceId);
                    psUpd.executeUpdate();
                }
                JOptionPane.showMessageDialog(this, "Attendance updated");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving attendance: " + ex.getMessage());
        }
    }

    private void clearForm() {
        empSelector.setSelectedIndex(0);
        tDate.setText(LocalDate.now().toString());
        statusCombo.setSelectedItem("PRESENT");
        tCheckIn.setText("09:00:00");
        tCheckOut.setText("17:00:00");
    }
}
