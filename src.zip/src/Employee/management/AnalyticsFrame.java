package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AnalyticsFrame extends JFrame {

    JLabel lblTotalEmp, lblActiveEmp, lblInactiveEmp, lblTotalLeaves;
    JTable tblDeptCount;

    public AnalyticsFrame() {
        setTitle("Analytics / Reports");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 700, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Analytics & Summary");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(220, 20, 300, 30);
        header.add(heading);
        add(header);

        lblTotalEmp = new JLabel("Total Employees: 0");
        lblActiveEmp = new JLabel("Active: 0");
        lblInactiveEmp = new JLabel("Inactive: 0");
        lblTotalLeaves = new JLabel("Total Leave Applications: 0");

        lblTotalEmp.setBounds(40, 90, 250, 25);
        lblActiveEmp.setBounds(40, 120, 250, 25);
        lblInactiveEmp.setBounds(40, 150, 250, 25);
        lblTotalLeaves.setBounds(40, 180, 300, 25);

        Font f = new Font("SansSerif", Font.BOLD, 14);
        lblTotalEmp.setFont(f);
        lblActiveEmp.setFont(f);
        lblInactiveEmp.setFont(f);
        lblTotalLeaves.setFont(f);

        add(lblTotalEmp);
        add(lblActiveEmp);
        add(lblInactiveEmp);
        add(lblTotalLeaves);

        JLabel lDept = new JLabel("Employees per Department:");
        lDept.setBounds(40, 220, 250, 25);
        lDept.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(lDept);

        String[] cols = {"Department", "Count"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblDeptCount = new JTable(model);
        tblDeptCount.setRowHeight(22);

        JScrollPane sp = new JScrollPane(tblDeptCount);
        sp.setBounds(40, 250, 600, 200);
        add(sp);

        setSize(700, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadSummary();
    }

    private void loadSummary() {
        String sqlTotal = "SELECT COUNT(*) AS c FROM employees";
        String sqlActive = "SELECT COUNT(*) AS c FROM employees WHERE status='ACTIVE'";
        String sqlInactive = "SELECT COUNT(*) AS c FROM employees WHERE status='INACTIVE'";
        String sqlLeaves = "SELECT COUNT(*) AS c FROM leave_applications";
        String sqlDept = "SELECT department, COUNT(*) AS c FROM employees GROUP BY department";

        try (Connection con = conn.getConnection()) {

            try (PreparedStatement ps = con.prepareStatement(sqlTotal);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) lblTotalEmp.setText("Total Employees: " + rs.getInt("c"));
            }

            try (PreparedStatement ps = con.prepareStatement(sqlActive);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) lblActiveEmp.setText("Active: " + rs.getInt("c"));
            }

            try (PreparedStatement ps = con.prepareStatement(sqlInactive);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) lblInactiveEmp.setText("Inactive: " + rs.getInt("c"));
            }

            try (PreparedStatement ps = con.prepareStatement(sqlLeaves);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) lblTotalLeaves.setText("Total Leave Applications: " + rs.getInt("c"));
            }

            DefaultTableModel model = (DefaultTableModel) tblDeptCount.getModel();
            model.setRowCount(0);

            try (PreparedStatement ps = con.prepareStatement(sqlDept);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getString("department"),
                            rs.getInt("c")
                    });
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading analytics: " + ex.getMessage());
        }
    }
}
