package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;   // for Connection, PreparedStatement, ResultSet, SQLException

public class AdminDashboard extends JFrame implements ActionListener {

    JPanel sidebar, contentPanel;
    JButton btnHome, btnEmployees, btnAttendance, btnLeave, btnPerformance,
            btnAnalytics, btnReports, btnGlobalSearch, btnSalarySlip, btnIdCard, btnLogout;

    int adminId;

    public AdminDashboard(int adminId) {
        this.adminId = adminId;

        setTitle("Admin Dashboard - Employee Management System");
        setLayout(null);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(245, 247, 250));
        setResizable(false);

        // Sidebar (left)
        sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBackground(new Color(25, 42, 86));  // dark blue
        sidebar.setBounds(0, 0, 220, 600);
        add(sidebar);

        JLabel title = new JLabel("<html><b>Admin Panel</b></html>", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setBounds(20, 20, 180, 30);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        sidebar.add(title);

        int y = 70;
        int h = 35;

        btnHome         = createSideButton("Home", y); y += h + 5;
        btnEmployees    = createSideButton("Employees", y); y += h + 5;
        btnAttendance   = createSideButton("Attendance", y); y += h + 5;
        btnLeave        = createSideButton("Leave", y); y += h + 5;
        btnPerformance  = createSideButton("Performance", y); y += h + 5;
        btnAnalytics    = createSideButton("Analytics", y); y += h + 5;
        btnReports      = createSideButton("Reports / Export", y); y += h + 5;
        btnGlobalSearch = createSideButton("Global Search", y); y += h + 5;
        btnSalarySlip   = createSideButton("Salary Slip", y); y += h + 5;
        btnIdCard       = createSideButton("Employee ID Card", y); y += h + 5;
        btnLogout       = createSideButton("Logout", 520);

        // Main content panel (right)
        contentPanel = new JPanel();
        contentPanel.setLayout(null);
        contentPanel.setBackground(new Color(245, 247, 250));
        contentPanel.setBounds(220, 0, 780, 600);
        add(contentPanel);

        // show default screen
        showHome();
    }

    private JButton createSideButton(String text, int y) {
        JButton b = new JButton(text);
        b.setBounds(20, y, 180, 35);
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(52, 73, 94));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(new Font("SansSerif", Font.PLAIN, 14));

        // Hover effect
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b.setBackground(new Color(52, 73, 94));
            }
        });

        b.addActionListener(this);
        sidebar.add(b);
        return b;
    }

    // ====== MAIN CONTENT HANDLING ======

    private void clearContent() {
        contentPanel.removeAll();
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showHome() {
        clearContent();

        // Gradient header bar
        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Admin Dashboard");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 24));
        heading.setBounds(20, 20, 400, 30);
        header.add(heading);

        JLabel sub = new JLabel("Overview of employees, attendance and leaves");
        sub.setForeground(Color.WHITE);
        sub.setFont(new Font("SansSerif", Font.PLAIN, 14));
        sub.setBounds(20, 50, 400, 20);
        header.add(sub);

        contentPanel.add(header);

        // Load simple stats from DB
        int totalEmp = 0, activeEmp = 0, pendingLeave = 0;
        try (Connection con = conn.getConnection()) {
            // total employees
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) AS c FROM employees");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalEmp = rs.getInt("c");
            }
            // active employees
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) AS c FROM employees WHERE status='ACTIVE'");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) activeEmp = rs.getInt("c");
            }
            // pending leaves
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) AS c FROM leave_applications WHERE status='PENDING'");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) pendingLeave = rs.getInt("c");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Stat cards
        JPanel card1 = createStatCard("Total Employees", String.valueOf(totalEmp), "All registered employees", 40, 110);
        JPanel card2 = createStatCard("Active Employees", String.valueOf(activeEmp), "Currently active", 280, 110);
        JPanel card3 = createStatCard("Pending Leaves", String.valueOf(pendingLeave), "Waiting for approval", 520, 110);

        contentPanel.add(card1);
        contentPanel.add(card2);
        contentPanel.add(card3);

        // Illustration
        try {
            ImageIcon icon = new ImageIcon("images/admin.png");  // make sure this file exists
            Image img = icon.getImage().getScaledInstance(420, 260, Image.SCALE_SMOOTH);
            JLabel imgLabel = new JLabel(new ImageIcon(img));
            imgLabel.setBounds(180, 230, 420, 260);
            contentPanel.add(imgLabel);
        } catch (Exception ex) {
            // ignore image error, UI will still work
        }
    }

    private JPanel createStatCard(String title, String value, String desc, int x, int y) {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(x, y, 200, 90);
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        panel.setOpaque(true);

        JLabel lTitle = new JLabel(title);
        lTitle.setBounds(10, 5, 180, 20);
        lTitle.setFont(new Font("SansSerif", Font.BOLD, 13));
        lTitle.setForeground(new Color(66, 66, 66));
        panel.add(lTitle);

        JLabel lValue = new JLabel(value);
        lValue.setBounds(10, 30, 180, 30);
        lValue.setFont(new Font("SansSerif", Font.BOLD, 22));
        lValue.setForeground(new Color(25, 118, 210));
        panel.add(lValue);

        JLabel lDesc = new JLabel(desc);
        lDesc.setBounds(10, 60, 180, 20);
        lDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lDesc.setForeground(new Color(120, 120, 120));
        panel.add(lDesc);

        return panel;
    }

    private void showEmployeesMenu() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Employee Management");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 400, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnAdd = createBigButton("Add Employee", 120, 130);
        btnAdd.addActionListener(e -> new AddEmployee().setVisible(true));
        contentPanel.add(btnAdd);

        JButton btnView = createBigButton("View Employees", 420, 130);
        btnView.addActionListener(e -> new View_Employee().setVisible(true));
        contentPanel.add(btnView);

        JButton btnUpdate = createBigButton("Update Employee", 120, 230);
        btnUpdate.addActionListener(e -> new UpdateEmployee().setVisible(true));
        contentPanel.add(btnUpdate);

        JButton btnRemove = createBigButton("Remove / Deactivate", 420, 230);
        btnRemove.addActionListener(e -> new RemoveEmployee().setVisible(true));
        contentPanel.add(btnRemove);
    }

    private void showAttendanceMenu() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Attendance Management");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 400, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnMark = createBigButton("Mark Attendance", 120, 150);
        btnMark.addActionListener(e -> new MarkAttendanceFrame().setVisible(true));
        contentPanel.add(btnMark);

        JButton btnView = createBigButton("View Attendance", 420, 150);
        btnView.addActionListener(e -> new AdminAttendanceViewFrame().setVisible(true));
        contentPanel.add(btnView);
    }

    private void showLeaveMenu() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Leave Management");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 400, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnApprove = createBigButton("Approve / Reject Leave", 120, 150);
        btnApprove.addActionListener(e -> new LeaveApprovalFrame(adminId).setVisible(true));
        contentPanel.add(btnApprove);

        JButton btnApply = createBigButton("Apply Leave (Admin)", 420, 150);
        btnApply.addActionListener(e -> new ApplyLeaveFrame().setVisible(true)); // admin mode
        contentPanel.add(btnApply);
    }

    private void showPerformanceMenu() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Performance Management");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 400, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnReview = createBigButton("Add Performance Review", 250, 150);
        btnReview.addActionListener(e -> new PerformanceFrame().setVisible(true));
        contentPanel.add(btnReview);
    }

    private void showAnalyticsScreen() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Analytics & Summary");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 400, 30);
        header.add(heading);
        contentPanel.add(header);

        JLabel info = new JLabel("Open detailed analytics in a separate window.", SwingConstants.CENTER);
        info.setBounds(120, 150, 540, 30);
        info.setFont(new Font("SansSerif", Font.PLAIN, 14));
        contentPanel.add(info);

        JButton btnOpen = createBigButton("Open Analytics Window", 260, 210);
        btnOpen.addActionListener(e -> new AnalyticsFrame().setVisible(true));
        contentPanel.add(btnOpen);
    }

    private void showReportsInfo() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Reports & Export", SwingConstants.LEFT);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 300, 30);
        header.add(heading);
        contentPanel.add(header);

        JTextArea info = new JTextArea(
                "- View Employees  : Print / Export CSV\n" +
                        "- Attendance View : Print / Export CSV\n" +
                        "- Leave Approval  : Print / Export CSV\n\n" +
                        "CSV files can be opened in Microsoft Excel.\n" +
                        "Salary Slips and ID Cards can be printed individually."
        );
        info.setEditable(false);
        info.setBackground(new Color(245, 247, 250));
        info.setFont(new Font("SansSerif", Font.PLAIN, 14));
        info.setBounds(80, 130, 620, 200);
        contentPanel.add(info);
    }

    private void showGlobalSearchInfo() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Global Search", SwingConstants.LEFT);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 300, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnOpen = createBigButton("Open Global Search", 260, 180);
        btnOpen.addActionListener(e -> new GlobalSearchFrame().setVisible(true));
        contentPanel.add(btnOpen);
    }

    private void showSalarySlipInfo() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Salary Slip", SwingConstants.LEFT);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 300, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnOpen = createBigButton("Generate Salary Slip", 260, 180);
        btnOpen.addActionListener(e -> new SalarySlipFrame().setVisible(true));
        contentPanel.add(btnOpen);
    }

    private void showIdCardInfo() {
        clearContent();

        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Employee ID Card", SwingConstants.LEFT);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 25, 300, 30);
        header.add(heading);
        contentPanel.add(header);

        JButton btnOpen = createBigButton("Generate ID Card", 260, 180);
        btnOpen.addActionListener(e -> new EmployeeIdCardFrame().setVisible(true));
        contentPanel.add(btnOpen);
    }

    private JButton createBigButton(String text, int x, int y) {
        JButton b = new JButton(text);
        b.setBounds(x, y, 220, 60);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("SansSerif", Font.BOLD, 14));
        return b;
    }

    // ====== SIDEBAR HANDLER ======
    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnHome) {
            showHome();
        } else if (src == btnEmployees) {
            showEmployeesMenu();
        } else if (src == btnAttendance) {
            showAttendanceMenu();
        } else if (src == btnLeave) {
            showLeaveMenu();
        } else if (src == btnPerformance) {
            showPerformanceMenu();
        } else if (src == btnAnalytics) {
            showAnalyticsScreen();
        } else if (src == btnReports) {
            showReportsInfo();
        } else if (src == btnGlobalSearch) {
            showGlobalSearchInfo();
        } else if (src == btnSalarySlip) {
            showSalarySlipInfo();
        } else if (src == btnIdCard) {
            showIdCardInfo();
        } else if (src == btnLogout) {
            dispose();
            new Login().setVisible(true);
        }
    }

    // Small inner class for gradient bar
    private static class GradientPanel extends JPanel {
        private final Color c1;
        private final Color c2;

        public GradientPanel(Color c1, Color c2) {
            this.c1 = c1;
            this.c2 = c2;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(
                    0, 0, c1,
                    getWidth(), getHeight(), c2
            );
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}
