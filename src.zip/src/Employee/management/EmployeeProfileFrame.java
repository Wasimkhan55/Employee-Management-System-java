package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class EmployeeProfileFrame extends JFrame {

    int employeeId;
    JTextArea detailsArea;
    JButton btnPrint, btnClose;

    public EmployeeProfileFrame(int employeeId) {
        this.employeeId = employeeId;

        setTitle("Employee Profile");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 500, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Employee Profile");
        heading.setBounds(160, 20, 300, 30);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        header.add(heading);
        add(header);

        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane sp = new JScrollPane(detailsArea);
        sp.setBounds(40, 90, 420, 230);
        add(sp);

        btnPrint = new JButton("Print Profile");
        btnPrint.setBounds(120, 340, 120, 30);
        btnPrint.setBackground(new Color(25, 118, 210));
        btnPrint.setForeground(Color.WHITE);
        btnPrint.addActionListener(e -> printProfile());
        add(btnPrint);

        btnClose = new JButton("Close");
        btnClose.setBounds(260, 340, 100, 30);
        btnClose.setBackground(new Color(25, 118, 210));
        btnClose.setForeground(Color.WHITE);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(500, 430);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployeeData();
    }

    private void loadEmployeeData() {
        String sql = "SELECT * FROM employees WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Emp Code : ").append(rs.getString("emp_code")).append("\n");
                sb.append("Name     : ").append(rs.getString("name")).append("\n");
                sb.append("Dept     : ").append(rs.getString("department")).append("\n");
                sb.append("Designation: ").append(rs.getString("designation")).append("\n");
                sb.append("Salary   : ").append(rs.getDouble("salary")).append("\n");
                sb.append("DOJ      : ").append(rs.getDate("doj")).append("\n");
                sb.append("Phone    : ").append(rs.getString("phone")).append("\n");
                sb.append("Email    : ").append(rs.getString("email")).append("\n");
                sb.append("Address  : ").append(rs.getString("address")).append("\n");
                sb.append("Status   : ").append(rs.getString("status")).append("\n");

                detailsArea.setText(sb.toString());
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void printProfile() {
        try {
            detailsArea.print();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error printing: " + e.getMessage());
        }
    }
}
