package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SalarySlipFrame extends JFrame implements ActionListener {

    JComboBox<String> empSelector;
    JTextField tMonthYear; // e.g. "Jan 2025"
    JTextArea slipArea;
    JButton btnGenerate, btnPrint, btnClose;

    public SalarySlipFrame() {
        setTitle("Salary Slip Generator");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 600, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Salary Slip Generator");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(170, 20, 300, 30);
        header.add(heading);
        add(header);

        JLabel lEmp = new JLabel("Select Employee:");
        lEmp.setBounds(30, 90, 120, 25);
        add(lEmp);

        empSelector = new JComboBox<>();
        empSelector.setBounds(150, 90, 260, 25);
        add(empSelector);

        JLabel lMonth = new JLabel("Month & Year:");
        lMonth.setBounds(30, 125, 120, 25);
        add(lMonth);

        tMonthYear = new JTextField("Jan 2025");
        tMonthYear.setBounds(150, 125, 150, 25);
        add(tMonthYear);

        btnGenerate = createButton("Generate Slip");
        btnGenerate.setBounds(320, 125, 150, 25);
        btnGenerate.addActionListener(this);
        add(btnGenerate);

        slipArea = new JTextArea();
        slipArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JScrollPane sp = new JScrollPane(slipArea);
        sp.setBounds(30, 170, 540, 230);
        add(sp);

        btnPrint = createButton("Print");
        btnPrint.setBounds(170, 420, 100, 30);
        btnPrint.addActionListener(e -> printSlip());
        add(btnPrint);

        btnClose = createButton("Close");
        btnClose.setBounds(300, 420, 100, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployeeDropdown();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private Integer getSelectedEmployeeId() {
        Object sel = empSelector.getSelectedItem();
        if (sel == null) return null;
        String s = sel.toString();
        if (s.startsWith("Select")) return null;
        String[] parts = s.split(" - ");
        try { return Integer.parseInt(parts[0].trim()); } catch (Exception e) { return null; }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        generateSlip();
    }

    private void generateSlip() {
        Integer empId = getSelectedEmployeeId();
        if (empId == null) {
            JOptionPane.showMessageDialog(this, "Select an employee");
            return;
        }

        String monthYear = tMonthYear.getText().trim();
        if (monthYear.isEmpty()) monthYear = "Month 2025";

        String sql = "SELECT emp_code, name, department, designation, salary FROM employees WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String empCode = rs.getString("emp_code");
                String name = rs.getString("name");
                String dept = rs.getString("department");
                String desig = rs.getString("designation");
                double basic = rs.getDouble("salary");

                double hra = basic * 0.20;
                double da = basic * 0.10;
                double pf = basic * 0.12;
                double gross = basic + hra + da;
                double net = gross - pf;

                StringBuilder sb = new StringBuilder();
                sb.append("               COMPANY NAME HERE\n");
                sb.append("                 SALARY SLIP\n\n");
                sb.append("Month & Year : ").append(monthYear).append("\n");
                sb.append("Emp Code     : ").append(empCode).append("\n");
                sb.append("Name         : ").append(name).append("\n");
                sb.append("Department   : ").append(dept).append("\n");
                sb.append("Designation  : ").append(desig).append("\n");
                sb.append("--------------------------------------------------\n");
                sb.append(String.format("Basic Salary     : %.2f\n", basic));
                sb.append(String.format("HRA (20%%)        : %.2f\n", hra));
                sb.append(String.format("DA (10%%)         : %.2f\n", da));
                sb.append("--------------------------------------------------\n");
                sb.append(String.format("GROSS SALARY     : %.2f\n", gross));
                sb.append(String.format("PF (12%%)         : %.2f\n", pf));
                sb.append("--------------------------------------------------\n");
                sb.append(String.format("NET PAY          : %.2f\n", net));
                sb.append("--------------------------------------------------\n\n");
                sb.append("Signature of Employer\n");

                slipArea.setText(sb.toString());
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void printSlip() {
        try {
            slipArea.print();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error printing: " + e.getMessage());
        }
    }
}
