package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeDashboard extends JFrame implements ActionListener {

    JPanel sidebar, contentPanel;
    JButton btnProfile, btnAttendance, btnApplyLeave, btnLeaveStatus,
            btnPerformance, btnSalarySlip, btnChangePassword, btnLogout;

    int employeeId;
    String employeeName = "";

    public EmployeeDashboard(int employeeId) {
        this.employeeId = employeeId;

        setTitle("Employee Dashboard");
        setLayout(null);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(new Color(245, 247, 250));

        loadEmployeeName();

        // SIDE PANEL
        sidebar = new JPanel();
        sidebar.setBackground(new Color(25, 42, 86));
        sidebar.setBounds(0, 0, 220, 600);
        sidebar.setLayout(null);
        add(sidebar);

        JLabel title = new JLabel("<html><b>Employee Panel</b></html>", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setBounds(20, 20, 180, 30);
        sidebar.add(title);

        int y = 70;
        int h = 35;

        btnProfile        = addSideButton("My Profile", y); y += h + 5;
        btnAttendance     = addSideButton("My Attendance", y); y += h + 5;
        btnApplyLeave     = addSideButton("Apply Leave", y); y += h + 5;
        btnLeaveStatus    = addSideButton("My Leave Status", y); y += h + 5;
        btnPerformance    = addSideButton("My Performance", y); y += h + 5;
        btnSalarySlip     = addSideButton("My Salary Slip", y); y += h + 5;
        btnChangePassword = addSideButton("Change Password", y); y += h + 5;
        btnLogout         = addSideButton("Logout", 520);

        // MAIN CONTENT AREA
        contentPanel = new JPanel();
        contentPanel.setLayout(null);
        contentPanel.setBackground(new Color(245, 247, 250));
        contentPanel.setBounds(220, 0, 780, 600);
        add(contentPanel);

        showHome();
    }

    private JButton addSideButton(String text, int y) {
        JButton b = new JButton(text);
        b.setBounds(20, y, 180, 35);
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(52, 73, 94));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(new Font("SansSerif", Font.PLAIN, 14));

        // Hover effect
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b.setBackground(new Color(52, 73, 94));
            }
        });

        b.addActionListener(this);
        sidebar.add(b);
        return b;
    }

    private void loadEmployeeName() {
        String sql = "SELECT name FROM employees WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                employeeName = rs.getString("name");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // MAIN CONTENT PANEL
    private void clearContent() {
        contentPanel.removeAll();
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showHome() {
        clearContent();

        // Gradient header (like admin)
        GradientPanel header = new GradientPanel(
                new Color(21, 101, 192),
                new Color(66, 165, 245)
        );
        header.setBounds(0, 0, 780, 90);
        header.setLayout(null);

        JLabel heading = new JLabel("Employee Dashboard");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(20, 20, 400, 30);
        header.add(heading);

        JLabel sub = new JLabel("Overview of your attendance, leaves and performance");
        sub.setForeground(Color.WHITE);
        sub.setFont(new Font("SansSerif", Font.PLAIN, 14));
        sub.setBounds(20, 50, 450, 20);
        header.add(sub);

        contentPanel.add(header);

        // === Personal stats for this employee (like admin cards) ===
        int totalAttendance = 0;
        int presentDays = 0;
        int pendingLeaves = 0;

        try (Connection con = conn.getConnection()) {
            // total attendance records
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) AS c FROM attendance WHERE employee_id=?")) {
                ps.setInt(1, employeeId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) totalAttendance = rs.getInt("c");
            }

            // present days
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) AS c FROM attendance WHERE employee_id=? AND status='PRESENT'")) {
                ps.setInt(1, employeeId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) presentDays = rs.getInt("c");
            }

            // pending leaves
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) AS c FROM leave_applications WHERE employee_id=? AND status='PENDING'")) {
                ps.setInt(1, employeeId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) pendingLeaves = rs.getInt("c");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Stat cards (similar style to admin)
        JPanel card1 = createStatCard(
                "Total Attendance",
                String.valueOf(totalAttendance),
                "All days recorded",
                40, 110
        );
        JPanel card2 = createStatCard(
                "Present Days",
                String.valueOf(presentDays),
                "Days marked PRESENT",
                280, 110
        );
        JPanel card3 = createStatCard(
                "Pending Leaves",
                String.valueOf(pendingLeaves),
                "Leave requests awaiting approval",
                520, 110
        );

        contentPanel.add(card1);
        contentPanel.add(card2);
        contentPanel.add(card3);

        // Illustration at bottom (like admin)
        try {
            ImageIcon icon = new ImageIcon("images/employee.png"); // or admin.png if same
            Image img = icon.getImage().getScaledInstance(420, 260, Image.SCALE_SMOOTH);
            JLabel imgLabel = new JLabel(new ImageIcon(img));
            imgLabel.setBounds(180, 230, 420, 260);
            contentPanel.add(imgLabel);
        } catch (Exception ex) {
            // ignore if image missing
        }
    }

    private JPanel createStatCard(String title, String value, String desc, int x, int y) {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(x, y, 200, 90);
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        panel.setOpaque(true);

        JLabel lTitle = new JLabel(title);
        lTitle.setBounds(10, 5, 180, 20);
        lTitle.setFont(new Font("SansSerif", Font.BOLD, 13));
        lTitle.setForeground(new Color(66, 66, 66));
        panel.add(lTitle);

        JLabel lValue = new JLabel(value);
        lValue.setBounds(10, 30, 180, 30);
        lValue.setFont(new Font("SansSerif", Font.BOLD, 22));
        lValue.setForeground(new Color(25, 118, 210));
        panel.add(lValue);

        JLabel lDesc = new JLabel("<html>" + desc + "</html>");
        lDesc.setBounds(10, 60, 180, 25);
        lDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lDesc.setForeground(new Color(120, 120, 120));
        panel.add(lDesc);

        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnProfile) {
            new EmployeeProfileFrame(employeeId).setVisible(true);

        } else if (src == btnAttendance) {
            new EmployeeAttendanceFrame(employeeId).setVisible(true);

        } else if (src == btnApplyLeave) {
            new ApplyLeaveFrame(employeeId).setVisible(true);

        } else if (src == btnLeaveStatus) {
            new EmployeeLeaveStatusFrame(employeeId).setVisible(true);

        } else if (src == btnPerformance) {
            new EmployeePerformanceViewFrame(employeeId).setVisible(true);

        } else if (src == btnSalarySlip) {
            new SalarySlipFrame().setVisible(true); // employee picks own record

        } else if (src == btnChangePassword) {
            new ChangePasswordFrame(employeeId).setVisible(true);

        } else if (src == btnLogout) {
            dispose();
            new Login().setVisible(true);
        }
    }

    // gradient header inner class (same style as admin)
    private static class GradientPanel extends JPanel {
        private final Color c1;
        private final Color c2;

        public GradientPanel(Color c1, Color c2) {
            this.c1 = c1;
            this.c2 = c2;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, c1, getWidth(), getHeight(), c2);
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}
