package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {

    JTextField tusername;
    JPasswordField tpassword;
    JButton btnLogin, btnExit;
    JComboBox<String> roleCombo;

    public Login() {
        setTitle("Employee Management System - Login");
        setLayout(null);
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Background color
        getContentPane().setBackground(new Color(236, 239, 241));

        // Left blue gradient panel (branding)
        JPanel leftPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(21, 101, 192),
                        getWidth(), getHeight(), new Color(66, 165, 245)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        leftPanel.setBounds(0, 0, 260, 450);
        leftPanel.setLayout(null);

        JLabel appTitle = new JLabel("<html><b>Employee<br>Management<br>System</b></html>");
        appTitle.setForeground(Color.WHITE);
        appTitle.setFont(new Font("SansSerif", Font.BOLD, 22));
        appTitle.setBounds(40, 100, 200, 80);
        leftPanel.add(appTitle);

        JLabel appSub = new JLabel("<html>Secure HR Portal<br>Admin & Employee</html>");
        appSub.setForeground(Color.WHITE);
        appSub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        appSub.setBounds(40, 190, 200, 40);
        leftPanel.add(appSub);

        // Optional: small icon / illustration on left
        try {
            ImageIcon icon = new ImageIcon("images/admin.png"); // if exists
            Image img = icon.getImage().getScaledInstance(140, 100, Image.SCALE_SMOOTH);
            JLabel imgLabel = new JLabel(new ImageIcon(img));
            imgLabel.setBounds(60, 260, 140, 100);
            leftPanel.add(imgLabel);
        } catch (Exception ex) {
            // ignore if image missing
        }

        add(leftPanel);

        // Right side: login card
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBackground(Color.WHITE);
        card.setBounds(280, 60, 380, 300);
        card.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        JLabel heading = new JLabel("Login");
        heading.setFont(new Font("SansSerif", Font.BOLD, 20));
        heading.setForeground(new Color(25, 118, 210));
        heading.setBounds(30, 20, 200, 25);
        card.add(heading);

        JLabel lusername = new JLabel("Username:");
        lusername.setBounds(30, 70, 120, 22);
        card.add(lusername);

        tusername = new JTextField();
        tusername.setBounds(130, 70, 210, 25);
        card.add(tusername);

        JLabel lpassword = new JLabel("Password:");
        lpassword.setBounds(30, 110, 120, 22);
        card.add(lpassword);

        tpassword = new JPasswordField();
        tpassword.setBounds(130, 110, 210, 25);
        card.add(tpassword);

        JLabel lrole = new JLabel("Login As:");
        lrole.setBounds(30, 150, 120, 22);
        card.add(lrole);

        roleCombo = new JComboBox<>(new String[]{"ADMIN", "EMPLOYEE"});
        roleCombo.setBounds(130, 150, 210, 25);
        card.add(roleCombo);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(80, 210, 100, 30);
        styleButton(btnLogin);
        btnLogin.addActionListener(this);
        card.add(btnLogin);

        btnExit = new JButton("Exit");
        btnExit.setBounds(200, 210, 100, 30);
        styleButton(btnExit);
        btnExit.addActionListener(e -> System.exit(0));
        card.add(btnExit);

        add(card);

        setVisible(true);
    }

    private void styleButton(JButton b) {
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));

        // Hover effect
        b.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                b.setBackground(new Color(21, 101, 192));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                b.setBackground(new Color(25, 118, 210));
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = tusername.getText().trim();
        String password = new String(tpassword.getPassword());
        String selectedRole = roleCombo.getSelectedItem().toString();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter username and password");
            return;
        }

        String sql = "SELECT id, role, employee_id FROM users WHERE username=? AND password=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String dbRole = rs.getString("role");
                int userId = rs.getInt("id");
                int employeeId = rs.getInt("employee_id");

                if (!dbRole.equals(selectedRole)) {
                    JOptionPane.showMessageDialog(this, "Role mismatch. Please select correct role.");
                    return;
                }

                JOptionPane.showMessageDialog(this, "Login successful as " + dbRole);

                this.dispose();
                if ("ADMIN".equals(dbRole)) {
                    new AdminDashboard(userId).setVisible(true);
                } else {
                    new EmployeeDashboard(employeeId).setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }
}
