package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RemoveEmployee extends JFrame implements ActionListener {

    JTextArea tDetails;
    JButton btnDeactivate, btnDelete, btnClear, btnClose, btnLoadSelected;

    JComboBox<String> empSelector;   // Employee dropdown: "id - EMP0001 - Name"

    int employeeId = -1;

    public RemoveEmployee() {
        setTitle("Remove / Deactivate Employee");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 560, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Remove / Deactivate Employee");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 18));
        heading.setBounds(110, 20, 350, 30);
        header.add(heading);
        add(header);

        // 🔹 Row 1: Dropdown
        JLabel lEmpSelect = new JLabel("Select Emp:");
        lEmpSelect.setBounds(30, 80, 80, 25);
        add(lEmpSelect);

        empSelector = new JComboBox<>();
        empSelector.setBounds(110, 80, 260, 25);
        add(empSelector);

        btnLoadSelected = createButton("Load");
        btnLoadSelected.setBounds(390, 80, 90, 25);
        btnLoadSelected.addActionListener(this);
        add(btnLoadSelected);

        // 🔹 Details area
        tDetails = new JTextArea();
        tDetails.setEditable(false);
        JScrollPane sp = new JScrollPane(tDetails);
        sp.setBounds(30, 130, 450, 180);
        add(sp);

        btnDeactivate = createButton("Mark INACTIVE");
        btnDeactivate.setBounds(30, 330, 140, 30);
        btnDeactivate.addActionListener(this);
        add(btnDeactivate);

        btnDelete = createButton("Delete Permanently");
        btnDelete.setBounds(180, 330, 170, 30);
        btnDelete.addActionListener(this);
        add(btnDelete);

        btnClear = createButton("Clear");
        btnClear.setBounds(360, 330, 80, 30);
        btnClear.addActionListener(e -> clearForm());
        add(btnClear);

        btnClose = createButton("Close");
        btnClose.setBounds(210, 375, 100, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(560, 460);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // 🔹 Load employee list
        loadEmployeeDropdown();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String code = rs.getString("emp_code");
                String name = rs.getString("name");

                empSelector.addItem(id + " - " + code + " - " + name);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnLoadSelected) {
            searchFromDropdown();
        } else if (src == btnDeactivate) {
            deactivateEmployee();
        } else if (src == btnDelete) {
            deleteEmployee();
        }
    }

    private void searchFromDropdown() {
        Object sel = empSelector.getSelectedItem();
        if (sel == null || "Select Employee".equals(sel.toString())) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        String[] parts = sel.toString().split(" - ");
        if (parts.length < 1) {
            JOptionPane.showMessageDialog(this, "Invalid employee format");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(parts[0].trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid employee selection");
            return;
        }

        searchEmployeeById(id);
    }

    private void searchEmployeeById(int id) {
        String sql = "SELECT * FROM employees WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                employeeId = rs.getInt("id");

                StringBuilder sb = new StringBuilder();
                sb.append("ID        : ").append(rs.getInt("id")).append("\n");
                sb.append("Emp Code  : ").append(rs.getString("emp_code")).append("\n");
                sb.append("Name      : ").append(rs.getString("name")).append("\n");
                sb.append("Dept      : ").append(rs.getString("department")).append("\n");
                sb.append("Designation: ").append(rs.getString("designation")).append("\n");
                sb.append("Salary    : ").append(rs.getDouble("salary")).append("\n");
                sb.append("DOJ       : ").append(rs.getDate("doj")).append("\n");
                sb.append("Phone     : ").append(rs.getString("phone")).append("\n");
                sb.append("Email     : ").append(rs.getString("email")).append("\n");
                sb.append("Status    : ").append(rs.getString("status")).append("\n");

                tDetails.setText(sb.toString());
            } else {
                employeeId = -1;
                tDetails.setText("");
                JOptionPane.showMessageDialog(this, "Employee not found");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error searching employee: " + ex.getMessage());
        }
    }

    private void deactivateEmployee() {
        if (employeeId == -1) {
            JOptionPane.showMessageDialog(this, "Load an employee first");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Mark this employee as INACTIVE and remove login?",
                "Confirm Deactivate",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        String sqlEmp = "UPDATE employees SET status='INACTIVE' WHERE id=?";
        String sqlUser = "DELETE FROM users WHERE employee_id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement psEmp = con.prepareStatement(sqlEmp);
             PreparedStatement psUser = con.prepareStatement(sqlUser)) {

            psEmp.setInt(1, employeeId);
            psEmp.executeUpdate();

            psUser.setInt(1, employeeId);
            psUser.executeUpdate();

            JOptionPane.showMessageDialog(this, "Employee INACTIVE and login removed");
            clearForm();
            loadEmployeeDropdown();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deactivating employee: " + ex.getMessage());
        }
    }

    private void deleteEmployee() {
        if (employeeId == -1) {
            JOptionPane.showMessageDialog(this, "Load an employee first");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "This will permanently delete employee and all related records.\nAre you sure?",
                "PERMANENT DELETE",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        Connection con = null;
        try {
            con = conn.getConnection();
            con.setAutoCommit(false);

            try (PreparedStatement ps1 = con.prepareStatement("DELETE FROM attendance WHERE employee_id=?");
                 PreparedStatement ps2 = con.prepareStatement("DELETE FROM leave_applications WHERE employee_id=?");
                 PreparedStatement ps3 = con.prepareStatement("DELETE FROM performance_reviews WHERE employee_id=?");
                 PreparedStatement ps4 = con.prepareStatement("DELETE FROM users WHERE employee_id=?");
                 PreparedStatement ps5 = con.prepareStatement("DELETE FROM employees WHERE id=?")) {

                ps1.setInt(1, employeeId);
                ps1.executeUpdate();

                ps2.setInt(1, employeeId);
                ps2.executeUpdate();

                ps3.setInt(1, employeeId);
                ps3.executeUpdate();

                ps4.setInt(1, employeeId);
                ps4.executeUpdate();

                ps5.setInt(1, employeeId);
                ps5.executeUpdate();
            }

            con.commit();
            JOptionPane.showMessageDialog(this, "Employee and related data deleted");
            clearForm();
            loadEmployeeDropdown();

        } catch (SQLException ex) {
            ex.printStackTrace();
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this, "Error deleting employee: " + ex.getMessage());
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ex2) {
                    ex2.printStackTrace();
                }
            }
        }
    }

    private void clearForm() {
        employeeId = -1;
        tDetails.setText("");
        empSelector.setSelectedIndex(0);
    }
}
