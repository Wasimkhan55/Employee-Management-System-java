package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.awt.print.PrinterException;
import java.sql.*;
import java.text.MessageFormat;

public class View_Employee extends JFrame implements ActionListener {

    JComboBox<String> empSelector;     // "All Employees" or "id - EMP0001 - Name"
    JComboBox<String> deptFilter;
    JComboBox<String> desigFilter;
    JComboBox<String> statusFilter;

    JButton btnFilter, btnShowAll, btnMarkInactive, btnClose, btnPrint;
    JTable table;
    DefaultTableModel model;

    public View_Employee() {
        setTitle("View / Manage Employees");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        // Header Panel
        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 900, 60);
        header.setLayout(null);

        JLabel heading = new JLabel("Employee List");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 24));
        heading.setBounds(20, 15, 300, 30);
        header.add(heading);
        add(header);

        // 🔹 Row 1: Employee dropdown + Print + Show All
        JLabel lEmpSelect = new JLabel("Employee:");
        lEmpSelect.setBounds(20, 75, 80, 25);
        add(lEmpSelect);

        empSelector = new JComboBox<>();
        empSelector.setBounds(95, 75, 260, 25);
        add(empSelector);

        btnFilter = createButton("Filter");
        btnFilter.setBounds(370, 75, 90, 25);
        btnFilter.addActionListener(this);
        add(btnFilter);

        btnShowAll = createButton("Show All");
        btnShowAll.setBounds(470, 75, 100, 25);
        btnShowAll.addActionListener(this);
        add(btnShowAll);

        btnPrint = createButton("Print");
        btnPrint.setBounds(580, 75, 80, 25);
        btnPrint.addActionListener(this);
        add(btnPrint);

        // 🔹 Row 2: Filters (Dept / Desig / Status)
        JLabel lDept = new JLabel("Dept:");
        lDept.setBounds(20, 110, 50, 25);
        add(lDept);

        deptFilter = new JComboBox<>(new String[]{
                "All", "IT", "HR", "Finance", "Sales", "Admin", "Operations"
        });
        deptFilter.setBounds(60, 110, 100, 25);
        add(deptFilter);

        JLabel lDesig = new JLabel("Desig:");
        lDesig.setBounds(180, 110, 50, 25);
        add(lDesig);

        desigFilter = new JComboBox<>(new String[]{
                "All", "Developer", "Manager", "Team Lead", "HR Executive", "Accountant"
        });
        desigFilter.setBounds(230, 110, 130, 25);
        add(desigFilter);

        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(380, 110, 60, 25);
        add(lStatus);

        statusFilter = new JComboBox<>(new String[]{"All", "ACTIVE", "INACTIVE"});
        statusFilter.setBounds(440, 110, 110, 25);
        add(statusFilter);

        // Table
        String[] cols = {"ID", "Emp Code", "Name", "Department", "Designation",
                "Salary", "DOJ", "Phone", "Email", "Status"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(22);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 145, 850, 320);
        add(sp);

        // Bottom Buttons
        btnMarkInactive = createButton("Mark as INACTIVE");
        btnMarkInactive.setBounds(200, 480, 170, 30);
        btnMarkInactive.addActionListener(this);
        add(btnMarkInactive);

        btnClose = createButton("Close");
        btnClose.setBounds(400, 480, 120, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        loadEmployeeDropdown();
        loadAllEmployees();

        setSize(900, 560);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("All Employees");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnFilter) {
            filterEmployees();
        } else if (src == btnShowAll) {
            // reset filters and load all
            empSelector.setSelectedIndex(0);
            deptFilter.setSelectedIndex(0);
            desigFilter.setSelectedIndex(0);
            statusFilter.setSelectedIndex(0);
            loadAllEmployees();
        } else if (src == btnMarkInactive) {
            markEmployeeInactive();
        } else if (src == btnPrint) {
            printEmployees();
        }
    }

    private void printEmployees() {
        try {
            MessageFormat header = new MessageFormat("Employee List");
            MessageFormat footer = new MessageFormat("Page {0}");
            boolean done = table.print(JTable.PrintMode.FIT_WIDTH, header, footer);
            if (!done) {
                JOptionPane.showMessageDialog(this, "Printing was cancelled");
            }
        } catch (PrinterException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error printing: " + ex.getMessage());
        }
    }

    private void loadAllEmployees() {
        model.setRowCount(0);
        String sql = "SELECT id, emp_code, name, department, designation, salary, doj, phone, email, status " +
                "FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("emp_code"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getString("designation"),
                        rs.getDouble("salary"),
                        rs.getDate("doj"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    private void filterEmployees() {
        String dept = deptFilter.getSelectedItem().toString();
        String desig = desigFilter.getSelectedItem().toString();
        String status = statusFilter.getSelectedItem().toString();
        Object selEmp = empSelector.getSelectedItem();

        StringBuilder sql = new StringBuilder(
                "SELECT id, emp_code, name, department, designation, salary, doj, phone, email, status " +
                        "FROM employees WHERE 1=1"
        );

        boolean hasEmp = selEmp != null && !"All Employees".equals(selEmp.toString());
        if (hasEmp) {
            sql.append(" AND id = ?");
        }
        if (!"All".equals(dept)) {
            sql.append(" AND department = ?");
        }
        if (!"All".equals(desig)) {
            sql.append(" AND designation = ?");
        }
        if (!"All".equals(status)) {
            sql.append(" AND status = ?");
        }

        sql.append(" ORDER BY emp_code");
        model.setRowCount(0);

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int idx = 1;

            if (hasEmp) {
                String[] parts = selEmp.toString().split(" - ");
                int empId = Integer.parseInt(parts[0].trim());
                ps.setInt(idx++, empId);
            }
            if (!"All".equals(dept)) {
                ps.setString(idx++, dept);
            }
            if (!"All".equals(desig)) {
                ps.setString(idx++, desig);
            }
            if (!"All".equals(status)) {
                ps.setString(idx++, status);
            }

            ResultSet rs = ps.executeQuery();
            boolean any = false;

            while (rs.next()) {
                any = true;
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("emp_code"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getString("designation"),
                        rs.getDouble("salary"),
                        rs.getDate("doj"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("status")
                });
            }

            if (!any) {
                JOptionPane.showMessageDialog(this, "No employees match selected filters.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error filtering employees: " + ex.getMessage());
        }
    }

    private void markEmployeeInactive() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        int id = (int) model.getValueAt(selectedRow, 0);
        String empCode = (String) model.getValueAt(selectedRow, 1);
        String name = (String) model.getValueAt(selectedRow, 2);

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Mark employee " + empCode + " - " + name + " as INACTIVE?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "UPDATE employees SET status='INACTIVE' WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Employee marked as INACTIVE");
            filterEmployees();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating employee: " + ex.getMessage());
        }
    }
}
