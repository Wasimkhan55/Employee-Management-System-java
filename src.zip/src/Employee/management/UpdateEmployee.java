package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateEmployee extends JFrame implements ActionListener {

    JComboBox<String> empSelector;            // "id - EMP0001 - Name"
    JTextField tEmpCode, tName, tDept, tDesig, tSalary, tDOJ, tPhone, tEmail;
    JTextArea tAddress;
    JComboBox<String> statusCombo;
    JButton btnLoadSelected, btnUpdate, btnMarkInactive, btnClear, btnClose;

    int employeeId = -1;

    public UpdateEmployee() {
        setTitle("Update Employee");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 650, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Update Employee Details");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(170, 20, 320, 30);
        header.add(heading);
        add(header);

        JLabel lEmpSelect = new JLabel("Select Emp:");
        lEmpSelect.setBounds(30, 80, 90, 25);
        add(lEmpSelect);

        empSelector = new JComboBox<>();
        empSelector.setBounds(120, 80, 280, 25);
        add(empSelector);

        btnLoadSelected = createButton("Load");
        btnLoadSelected.setBounds(420, 80, 90, 25);
        btnLoadSelected.addActionListener(this);
        add(btnLoadSelected);

        int y = 120;
        int labelX = 30;
        int fieldX = 160;
        int w = 220;
        int gap = 35;

        JLabel lEmpCode = new JLabel("Emp Code:");
        lEmpCode.setBounds(labelX, y, 120, 25);
        add(lEmpCode);
        tEmpCode = new JTextField();
        tEmpCode.setBounds(fieldX, y, w, 25);
        tEmpCode.setEditable(false);
        add(tEmpCode);

        y += gap;
        JLabel lName = new JLabel("Name:");
        lName.setBounds(labelX, y, 120, 25);
        add(lName);
        tName = new JTextField();
        tName.setBounds(fieldX, y, w, 25);
        add(tName);

        y += gap;
        JLabel lDept = new JLabel("Department:");
        lDept.setBounds(labelX, y, 120, 25);
        add(lDept);
        tDept = new JTextField();
        tDept.setBounds(fieldX, y, w, 25);
        add(tDept);

        y += gap;
        JLabel lDesig = new JLabel("Designation:");
        lDesig.setBounds(labelX, y, 120, 25);
        add(lDesig);
        tDesig = new JTextField();
        tDesig.setBounds(fieldX, y, w, 25);
        add(tDesig);

        y += gap;
        JLabel lSalary = new JLabel("Salary:");
        lSalary.setBounds(labelX, y, 120, 25);
        add(lSalary);
        tSalary = new JTextField();
        tSalary.setBounds(fieldX, y, w, 25);
        add(tSalary);

        y += gap;
        JLabel lDOJ = new JLabel("DOJ (yyyy-MM-dd):");
        lDOJ.setBounds(labelX, y, 150, 25);
        add(lDOJ);
        tDOJ = new JTextField();
        tDOJ.setBounds(fieldX, y, w, 25);
        add(tDOJ);

        y += gap;
        JLabel lPhone = new JLabel("Phone:");
        lPhone.setBounds(labelX, y, 120, 25);
        add(lPhone);
        tPhone = new JTextField();
        tPhone.setBounds(fieldX, y, w, 25);
        add(tPhone);

        y += gap;
        JLabel lEmail = new JLabel("Email:");
        lEmail.setBounds(labelX, y, 120, 25);
        add(lEmail);
        tEmail = new JTextField();
        tEmail.setBounds(fieldX, y, w, 25);
        add(tEmail);

        y += gap;
        JLabel lAddress = new JLabel("Address:");
        lAddress.setBounds(labelX, y, 120, 25);
        add(lAddress);
        tAddress = new JTextArea();
        JScrollPane spAddress = new JScrollPane(tAddress);
        spAddress.setBounds(fieldX, y, w, 60);
        add(spAddress);

        y += 70;
        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(labelX, y, 120, 25);
        add(lStatus);
        statusCombo = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});
        statusCombo.setBounds(fieldX, y, w, 25);
        add(statusCombo);

        btnUpdate = createButton("Update");
        btnUpdate.setBounds(60, y + 50, 110, 30);
        btnUpdate.addActionListener(this);
        add(btnUpdate);

        btnMarkInactive = createButton("Mark INACTIVE");
        btnMarkInactive.setBounds(190, y + 50, 150, 30);
        btnMarkInactive.addActionListener(this);
        add(btnMarkInactive);

        btnClear = createButton("Clear");
        btnClear.setBounds(350, y + 50, 90, 30);
        btnClear.addActionListener(ev -> clearFields());
        add(btnClear);

        btnClose = createButton("Close");
        btnClose.setBounds(450, y + 50, 90, 30);
        btnClose.addActionListener(ev -> dispose());
        add(btnClose);

        setSize(650, y + 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployeeDropdown();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";
        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnLoadSelected) {
            loadSelectedEmployee();
        } else if (src == btnUpdate) {
            updateEmployee();
        } else if (src == btnMarkInactive) {
            markInactive();
        }
    }

    private void loadSelectedEmployee() {
        Object sel = empSelector.getSelectedItem();
        if (sel == null || "Select Employee".equals(sel.toString())) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        String[] parts = sel.toString().split(" - ");
        if (parts.length < 1) {
            JOptionPane.showMessageDialog(this, "Invalid employee format");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(parts[0].trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid employee selection");
            return;
        }

        searchEmployeeById(id);
    }

    private void searchEmployeeById(int id) {
        String sql = "SELECT * FROM employees WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                employeeId = rs.getInt("id");
                tEmpCode.setText(rs.getString("emp_code"));
                tName.setText(rs.getString("name"));
                tDept.setText(rs.getString("department"));
                tDesig.setText(rs.getString("designation"));
                tSalary.setText(String.valueOf(rs.getDouble("salary")));
                tDOJ.setText(rs.getString("doj"));
                tPhone.setText(rs.getString("phone"));
                tEmail.setText(rs.getString("email"));
                tAddress.setText(rs.getString("address"));
                statusCombo.setSelectedItem(rs.getString("status"));
            } else {
                employeeId = -1;
                clearFields();
                JOptionPane.showMessageDialog(this, "Employee not found");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employee: " + ex.getMessage());
        }
    }

    private void updateEmployee() {
        if (employeeId == -1) {
            JOptionPane.showMessageDialog(this, "Load an employee first");
            return;
        }

        String name = tName.getText().trim();
        String dept = tDept.getText().trim();
        String desig = tDesig.getText().trim();
        String salaryStr = tSalary.getText().trim();
        String doj = tDOJ.getText().trim();
        String phone = tPhone.getText().trim();
        String email = tEmail.getText().trim();
        String address = tAddress.getText().trim();
        String status = statusCombo.getSelectedItem().toString();

        if (name.isEmpty() || salaryStr.isEmpty() || doj.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name, Salary, DOJ are required");
            return;
        }

        double salary;
        try {
            salary = Double.parseDouble(salaryStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid salary");
            return;
        }

        String sql = "UPDATE employees SET name=?, department=?, designation=?, salary=?, doj=?, " +
                "phone=?, email=?, address=?, status=? WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, dept);
            ps.setString(3, desig);
            ps.setDouble(4, salary);
            ps.setString(5, doj);
            ps.setString(6, phone);
            ps.setString(7, email);
            ps.setString(8, address);
            ps.setString(9, status);
            ps.setInt(10, employeeId);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Employee updated successfully!");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating employee: " + ex.getMessage());
        }
    }

    private void markInactive() {
        if (employeeId == -1) {
            JOptionPane.showMessageDialog(this, "Load an employee first");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Mark this employee as INACTIVE?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "UPDATE employees SET status='INACTIVE' WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Employee marked as INACTIVE");
            statusCombo.setSelectedItem("INACTIVE");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating status: " + ex.getMessage());
        }
    }

    private void clearFields() {
        employeeId = -1;
        tEmpCode.setText("");
        tName.setText("");
        tDept.setText("");
        tDesig.setText("");
        tSalary.setText("");
        tDOJ.setText("");
        tPhone.setText("");
        tEmail.setText("");
        tAddress.setText("");
        if (statusCombo != null) statusCombo.setSelectedIndex(0);
    }
}
