package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PerformanceFrame extends JFrame implements ActionListener {

    JComboBox<String> empSelector;   // "id - EMP0001 - Name"
    JTextField tRating;
    JTextArea tRemarks;
    JButton btnSave, btnClear, btnClose, btnReload, btnLoadReviews;
    JTable table;
    DefaultTableModel model;

    public PerformanceFrame() {
        setTitle("Employee Performance Review");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 820, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Performance Review");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(290, 20, 300, 30);
        header.add(heading);
        add(header);

        // 🔹 Dropdown row (no emp code text field)
        JLabel lEmpSelect = new JLabel("Select Emp:");
        lEmpSelect.setBounds(40, 85, 100, 25);
        add(lEmpSelect);

        empSelector = new JComboBox<>();
        empSelector.setBounds(130, 85, 230, 25);
        add(empSelector);

        btnReload = createButton("Reload");
        btnReload.setBounds(370, 85, 90, 25);
        btnReload.addActionListener(e -> loadEmployeeDropdown());
        add(btnReload);

        btnLoadReviews = createButton("Load Reviews");
        btnLoadReviews.setBounds(480, 85, 140, 25);
        btnLoadReviews.addActionListener(e -> loadReviews());
        add(btnLoadReviews);

        JLabel l2 = new JLabel("Rating (1-10):");
        l2.setBounds(40, 130, 120, 25);
        add(l2);

        tRating = new JTextField();
        tRating.setBounds(130, 130, 170, 25);
        add(tRating);

        JLabel l3 = new JLabel("Remarks:");
        l3.setBounds(40, 170, 120, 25);
        add(l3);

        tRemarks = new JTextArea();
        JScrollPane spRemarks = new JScrollPane(tRemarks);
        spRemarks.setBounds(130, 170, 220, 100);
        add(spRemarks);

        btnSave = createButton("Save Review");
        btnSave.setBounds(40, 290, 140, 30);
        btnSave.addActionListener(this);
        add(btnSave);

        btnClear = createButton("Clear");
        btnClear.setBounds(190, 290, 90, 30);
        btnClear.addActionListener(e -> clearForm());
        add(btnClear);

        btnClose = createButton("Close");
        btnClose.setBounds(290, 290, 90, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        String[] cols = {"Emp ID", "Name", "Rating", "Remarks"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(22);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(380, 130, 410, 230);
        add(sp);

        setSize(820, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployeeDropdown();
        loadReviews();
    }

    private JButton createButton(String txt) {
        JButton b = new JButton(txt);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";
        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private Integer getSelectedEmployeeId() {
        Object sel = empSelector.getSelectedItem();
        if (sel == null) return null;
        String s = sel.toString();
        if (s.startsWith("Select")) return null;

        String[] parts = s.split(" - ");
        if (parts.length < 1) return null;

        try {
            return Integer.parseInt(parts[0].trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        savePerformance();
    }

    private void savePerformance() {
        Integer employeeId = getSelectedEmployeeId();
        String ratingStr = tRating.getText().trim();
        String remarks = tRemarks.getText().trim();

        if (employeeId == null) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        if (ratingStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter rating");
            return;
        }

        int rating;
        try {
            rating = Integer.parseInt(ratingStr);
            if (rating < 1 || rating > 10) {
                throw new NumberFormatException();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Rating must be between 1 and 10");
            return;
        }

        String sql = "INSERT INTO performance_reviews (employee_id, rating, remarks) VALUES (?, ?, ?)";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ps.setInt(2, rating);
            ps.setString(3, remarks);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Review saved successfully");
            clearForm();
            loadReviews();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadReviews() {
        model.setRowCount(0);

        String sql = "SELECT pr.employee_id, e.name, pr.rating, pr.remarks " +
                "FROM performance_reviews pr " +
                "JOIN employees e ON pr.employee_id = e.id " +
                "ORDER BY pr.id DESC";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getString(4)
                });
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void clearForm() {
        empSelector.setSelectedIndex(0);
        tRating.setText("");
        tRemarks.setText("");
    }
}
