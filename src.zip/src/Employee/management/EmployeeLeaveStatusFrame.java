package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EmployeeLeaveStatusFrame extends JFrame {

    int employeeId;
    JTable table;
    DefaultTableModel model;
    JComboBox<String> statusFilter;
    JButton btnFilter, btnShowAll, btnClose;

    public EmployeeLeaveStatusFrame(int employeeId) {
        this.employeeId = employeeId;

        setTitle("My Leave Status");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 750, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("My Leave Applications");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(230, 20, 300, 30);
        header.add(heading);
        add(header);

        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(20, 85, 60, 25);
        add(lStatus);

        statusFilter = new JComboBox<>(new String[]{"All", "PENDING", "APPROVED", "REJECTED"});
        statusFilter.setBounds(80, 85, 130, 25);
        add(statusFilter);

        btnFilter = createButton("Filter");
        btnFilter.setBounds(230, 85, 80, 25);
        btnFilter.addActionListener(e -> loadLeaves());
        add(btnFilter);

        btnShowAll = createButton("Show All");
        btnShowAll.setBounds(320, 85, 100, 25);
        btnShowAll.addActionListener(e -> {
            statusFilter.setSelectedIndex(0);
            loadLeaves();
        });
        add(btnShowAll);

        String[] cols = {"Leave Type", "Start Date", "End Date", "Reason", "Status"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(22);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 125, 700, 320);
        add(sp);

        btnClose = createButton("Close");
        btnClose.setBounds(320, 460, 100, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(750, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadLeaves();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadLeaves() {
        model.setRowCount(0);

        String status = statusFilter.getSelectedItem().toString();

        StringBuilder sql = new StringBuilder(
                "SELECT leave_type, start_date, end_date, reason, status " +
                        "FROM leave_applications WHERE employee_id=?"
        );

        if (!"All".equals(status)) {
            sql.append(" AND status=?");
        }

        sql.append(" ORDER BY id DESC");

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int idx = 1;
            ps.setInt(idx++, employeeId);
            if (!"All".equals(status)) {
                ps.setString(idx++, status);
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("leave_type"),
                        rs.getString("start_date"),
                        rs.getString("end_date"),
                        rs.getString("reason"),
                        rs.getString("status")
                });
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
