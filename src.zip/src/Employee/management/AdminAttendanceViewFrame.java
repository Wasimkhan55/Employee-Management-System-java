package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminAttendanceViewFrame extends JFrame implements ActionListener {

    JTable table;
    DefaultTableModel model;

    JComboBox<String> empSelector;    // id - EMP0001 - Name
    JComboBox<String> statusFilter;   // All, PRESENT, ABSENT, LEAVE
    JTextField tFromDate, tToDate;    // yyyy-MM-dd

    JButton btnFilter, btnShowAll, btnClose, btnReloadEmp;

    public AdminAttendanceViewFrame() {
        setTitle("Attendance - Admin View");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 900, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Attendance Records (Admin)");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(230, 20, 400, 30);
        header.add(heading);
        add(header);

        // Row 1: Employee dropdown
        JLabel lEmp = new JLabel("Employee:");
        lEmp.setBounds(20, 80, 80, 25);
        add(lEmp);

        empSelector = new JComboBox<>();
        empSelector.setBounds(95, 80, 260, 25);
        add(empSelector);

        btnReloadEmp = createButton("Reload");
        btnReloadEmp.setBounds(365, 80, 90, 25);
        btnReloadEmp.addActionListener(e -> loadEmployeeDropdown());
        add(btnReloadEmp);

        // Row 2: Date range
        JLabel lFrom = new JLabel("From (yyyy-MM-dd):");
        lFrom.setBounds(20, 115, 130, 25);
        add(lFrom);

        tFromDate = new JTextField();
        tFromDate.setBounds(155, 115, 130, 25);
        add(tFromDate);

        JLabel lTo = new JLabel("To:");
        lTo.setBounds(295, 115, 25, 25);
        add(lTo);

        tToDate = new JTextField();
        tToDate.setBounds(325, 115, 130, 25);
        add(tToDate);

        // Row 3: Status + buttons
        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(480, 80, 60, 25);
        add(lStatus);

        statusFilter = new JComboBox<>(new String[]{"All", "PRESENT", "ABSENT", "LEAVE"});
        statusFilter.setBounds(540, 80, 120, 25);
        add(statusFilter);

        btnFilter = createButton("Filter");
        btnFilter.setBounds(680, 80, 90, 25);
        btnFilter.addActionListener(this);
        add(btnFilter);

        btnShowAll = createButton("Show All");
        btnShowAll.setBounds(780, 80, 90, 25);
        btnShowAll.addActionListener(this);
        add(btnShowAll);

        // Table
        String[] cols = {"Date", "Emp Code", "Name", "Status", "Check In", "Check Out"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(22);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 150, 850, 350);
        add(sp);

        btnClose = createButton("Close");
        btnClose.setBounds(380, 520, 120, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // Load initial data
        loadEmployeeDropdown();
        loadAllAttendance();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("All Employees");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    private void loadAllAttendance() {
        model.setRowCount(0);

        String sql = "SELECT a.date, e.emp_code, e.name, a.status, a.check_in, a.check_out " +
                "FROM attendance a " +
                "JOIN employees e ON a.employee_id = e.id " +
                "ORDER BY a.date DESC, e.emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getDate("date"),
                        rs.getString("emp_code"),
                        rs.getString("name"),
                        rs.getString("status"),
                        rs.getTime("check_in"),
                        rs.getTime("check_out")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void filterAttendance() {
        model.setRowCount(0);

        // Build SQL
        StringBuilder sql = new StringBuilder(
                "SELECT a.date, e.emp_code, e.name, a.status, a.check_in, a.check_out " +
                        "FROM attendance a " +
                        "JOIN employees e ON a.employee_id = e.id WHERE 1=1"
        );

        // Employee filter
        Object selEmp = empSelector.getSelectedItem();
        boolean hasEmp = selEmp != null && !"All Employees".equals(selEmp.toString());
        if (hasEmp) {
            sql.append(" AND a.employee_id = ?");
        }

        // Status filter
        String st = statusFilter.getSelectedItem().toString();
        if (!"All".equals(st)) {
            sql.append(" AND a.status = ?");
        }

        // Date range filter
        String from = tFromDate.getText().trim();
        String to = tToDate.getText().trim();
        boolean hasFrom = !from.isEmpty();
        boolean hasTo = !to.isEmpty();

        if (hasFrom) {
            sql.append(" AND a.date >= ?");
        }
        if (hasTo) {
            sql.append(" AND a.date <= ?");
        }

        sql.append(" ORDER BY a.date DESC, e.emp_code");

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int idx = 1;

            if (hasEmp) {
                String[] parts = selEmp.toString().split(" - ");
                int empId = Integer.parseInt(parts[0].trim());
                ps.setInt(idx++, empId);
            }

            if (!"All".equals(st)) {
                ps.setString(idx++, st);
            }

            if (hasFrom) {
                ps.setString(idx++, from);
            }
            if (hasTo) {
                ps.setString(idx++, to);
            }

            ResultSet rs = ps.executeQuery();
            boolean any = false;

            while (rs.next()) {
                any = true;
                model.addRow(new Object[]{
                        rs.getDate("date"),
                        rs.getString("emp_code"),
                        rs.getString("name"),
                        rs.getString("status"),
                        rs.getTime("check_in"),
                        rs.getTime("check_out")
                });
            }

            if (!any) {
                JOptionPane.showMessageDialog(this, "No attendance records match filters.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error filtering attendance: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnFilter) {
            filterAttendance();
        } else if (src == btnShowAll) {
            // reset filters and load all
            empSelector.setSelectedIndex(0);
            statusFilter.setSelectedIndex(0);
            tFromDate.setText("");
            tToDate.setText("");
            loadAllAttendance();
        }
    }
}
