package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EmployeePerformanceViewFrame extends JFrame {

    int employeeId;
    JTable table;
    DefaultTableModel model;
    JLabel lblAvgRating;
    JButton btnClose;

    public EmployeePerformanceViewFrame(int employeeId) {
        this.employeeId = employeeId;

        setTitle("My Performance Reviews");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 650, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("My Performance Reviews");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(170, 20, 320, 30);
        header.add(heading);
        add(header);

        lblAvgRating = new JLabel("Average Rating: N/A");
        lblAvgRating.setBounds(30, 85, 250, 25);
        lblAvgRating.setFont(new Font("SansSerif", Font.BOLD, 14));
        add(lblAvgRating);

        String[] cols = {"Rating", "Remarks"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(22);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30, 120, 580, 280);
        add(sp);

        btnClose = new JButton("Close");
        btnClose.setBounds(270, 420, 100, 30);
        btnClose.setBackground(new Color(25, 118, 210));
        btnClose.setForeground(Color.WHITE);
        btnClose.setFocusPainted(false);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(650, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadPerformance();
    }

    private void loadPerformance() {
        model.setRowCount(0);

        String sql = "SELECT rating, remarks FROM performance_reviews WHERE employee_id=? ORDER BY id DESC";
        String sqlAvg = "SELECT AVG(rating) AS avg_rating FROM performance_reviews WHERE employee_id=?";

        try (Connection con = conn.getConnection()) {

            try (PreparedStatement ps = con.prepareStatement(sql);
                 PreparedStatement psAvg = con.prepareStatement(sqlAvg)) {

                ps.setInt(1, employeeId);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getInt("rating"),
                            rs.getString("remarks")
                    });
                }

                psAvg.setInt(1, employeeId);
                ResultSet rs2 = psAvg.executeQuery();
                if (rs2.next()) {
                    double avg = rs2.getDouble("avg_rating");
                    if (rs2.wasNull()) {
                        lblAvgRating.setText("Average Rating: N/A");
                    } else {
                        lblAvgRating.setText(String.format("Average Rating: %.2f / 10", avg));
                    }
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
