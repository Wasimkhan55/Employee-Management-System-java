package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeAttendanceFrame extends JFrame implements ActionListener {

    int employeeId;

    JTable table;
    DefaultTableModel model;
    JTextField tFromDate, tToDate;
    JButton btnFilter, btnShowAll, btnClose;

    public EmployeeAttendanceFrame(int employeeId) {
        this.employeeId = employeeId;

        setTitle("My Attendance");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 700, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("My Attendance");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(260, 20, 200, 30);
        header.add(heading);
        add(header);

        JLabel lFrom = new JLabel("From (yyyy-MM-dd):");
        lFrom.setBounds(20, 85, 140, 25);
        add(lFrom);

        tFromDate = new JTextField();
        tFromDate.setBounds(160, 85, 120, 25);
        add(tFromDate);

        JLabel lTo = new JLabel("To:");
        lTo.setBounds(300, 85, 30, 25);
        add(lTo);

        tToDate = new JTextField();
        tToDate.setBounds(330, 85, 120, 25);
        add(tToDate);

        btnFilter = createButton("Filter");
        btnFilter.setBounds(470, 85, 80, 25);
        btnFilter.addActionListener(this);
        add(btnFilter);

        btnShowAll = createButton("Show All");
        btnShowAll.setBounds(560, 85, 100, 25);
        btnShowAll.addActionListener(this);
        add(btnShowAll);

        String[] cols = {"Date", "Status", "Check In", "Check Out"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(22);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 125, 640, 330);
        add(sp);

        btnClose = createButton("Close");
        btnClose.setBounds(290, 470, 100, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(700, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadAllAttendance();
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadAllAttendance() {
        model.setRowCount(0);

        String sql = "SELECT date, status, check_in, check_out " +
                "FROM attendance WHERE employee_id=? ORDER BY date DESC";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getDate("date"),
                        rs.getString("status"),
                        rs.getTime("check_in"),
                        rs.getTime("check_out")
                });
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void filterAttendance() {
        String from = tFromDate.getText().trim();
        String to = tToDate.getText().trim();

        StringBuilder sql = new StringBuilder(
                "SELECT date, status, check_in, check_out FROM attendance " +
                        "WHERE employee_id=?"
        );

        boolean hasFrom = !from.isEmpty();
        boolean hasTo = !to.isEmpty();

        if (hasFrom) sql.append(" AND date>=?");
        if (hasTo)   sql.append(" AND date<=?");

        sql.append(" ORDER BY date DESC");

        model.setRowCount(0);

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int idx = 1;
            ps.setInt(idx++, employeeId);

            if (hasFrom) ps.setString(idx++, from);
            if (hasTo)   ps.setString(idx++, to);

            ResultSet rs = ps.executeQuery();
            boolean any = false;

            while (rs.next()) {
                any = true;
                model.addRow(new Object[]{
                        rs.getDate("date"),
                        rs.getString("status"),
                        rs.getTime("check_in"),
                        rs.getTime("check_out")
                });
            }

            if (!any) {
                JOptionPane.showMessageDialog(this, "No records for selected range.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnFilter) {
            filterAttendance();
        } else if (src == btnShowAll) {
            tFromDate.setText("");
            tToDate.setText("");
            loadAllAttendance();
        }
    }
}
