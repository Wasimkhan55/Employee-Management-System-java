package Employee.management;

import javax.swing.SwingUtilities;

public class Main_class {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Splash());
    }
}
