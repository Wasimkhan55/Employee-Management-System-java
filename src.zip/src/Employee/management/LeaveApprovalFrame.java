package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LeaveApprovalFrame extends JFrame implements ActionListener {

    int adminId;
    JTable table;
    DefaultTableModel model;

    JButton btnApprove, btnReject, btnRefresh, btnFilter, btnClose;

    JComboBox<String> statusFilter;   // All, PENDING, APPROVED, REJECTED
    JComboBox<String> empSelector;    // id - EMP0001 - Name

    public LeaveApprovalFrame(int adminId) {
        this.adminId = adminId;

        setTitle("Leave Approval (Admin)");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 900, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Leave Approval Panel");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(300, 20, 300, 30);
        header.add(heading);
        add(header);

        // Row 1: Employee dropdown
        JLabel lEmp = new JLabel("Employee:");
        lEmp.setBounds(20, 80, 80, 25);
        add(lEmp);

        empSelector = new JComboBox<>();
        empSelector.setBounds(100, 80, 250, 25);
        add(empSelector);

        JButton btnReloadEmp = createButton("Reload");
        btnReloadEmp.setBounds(360, 80, 90, 25);
        btnReloadEmp.addActionListener(e -> loadEmployeeDropdown());
        add(btnReloadEmp);

        // Row 2: Status filter
        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(470, 80, 60, 25);
        add(lStatus);

        statusFilter = new JComboBox<>(new String[]{"All", "PENDING", "APPROVED", "REJECTED"});
        statusFilter.setBounds(530, 80, 120, 25);
        add(statusFilter);

        btnFilter = createButton("Filter");
        btnFilter.setBounds(670, 80, 90, 25);
        btnFilter.addActionListener(this);
        add(btnFilter);

        btnRefresh = createButton("Show All");
        btnRefresh.setBounds(770, 80, 100, 25);
        btnRefresh.addActionListener(this);
        add(btnRefresh);

        String[] cols = {"ID", "Emp ID", "Emp Code", "Name", "Leave Type", "Start", "End", "Reason", "Status"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(22);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 120, 850, 320);
        add(sp);

        btnApprove = createButton("Approve");
        btnApprove.setBounds(180, 460, 120, 30);
        btnApprove.addActionListener(this);
        add(btnApprove);

        btnReject = createButton("Reject");
        btnReject.setBounds(320, 460, 120, 30);
        btnReject.addActionListener(this);
        add(btnReject);

        btnClose = createButton("Close");
        btnClose.setBounds(460, 460, 120, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployeeDropdown();
        loadLeaves(null, null);   // default: all
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    private void loadEmployeeDropdown() {
        empSelector.removeAllItems();
        empSelector.addItem("All Employees");

        String sql = "SELECT id, emp_code, name FROM employees ORDER BY emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empSelector.addItem(
                        rs.getInt("id") + " - " +
                                rs.getString("emp_code") + " - " +
                                rs.getString("name")
                );
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadLeaves(Integer employeeId, String status) {
        model.setRowCount(0);

        StringBuilder sql = new StringBuilder(
                "SELECT l.id, l.employee_id, e.emp_code, e.name, l.leave_type, " +
                        "l.start_date, l.end_date, l.reason, l.status " +
                        "FROM leave_applications l " +
                        "JOIN employees e ON l.employee_id = e.id WHERE 1=1"
        );

        if (employeeId != null) {
            sql.append(" AND l.employee_id = ?");
        }

        if (status != null && !"All".equals(status)) {
            sql.append(" AND l.status = ?");
        }

        sql.append(" ORDER BY l.id DESC");

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int idx = 1;

            if (employeeId != null) {
                ps.setInt(idx++, employeeId);
            }

            if (status != null && !"All".equals(status)) {
                ps.setString(idx++, status);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getInt("employee_id"),
                        rs.getString("emp_code"),
                        rs.getString("name"),
                        rs.getString("leave_type"),
                        rs.getString("start_date"),
                        rs.getString("end_date"),
                        rs.getString("reason"),
                        rs.getString("status")
                });
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updateLeaveStatus(String newStatus) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a leave request.");
            return;
        }

        int leaveId = (int) model.getValueAt(row, 0);

        String sql = "UPDATE leave_applications SET status=? WHERE id=?";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setInt(2, leaveId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Leave " + newStatus.toLowerCase());
            // Reload with current filters
            handleFilter();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void handleFilter() {
        Integer empIdFilter = null;

        Object selEmp = empSelector.getSelectedItem();
        if (selEmp != null && !"All Employees".equals(selEmp.toString())) {
            String[] parts = selEmp.toString().split(" - ");
            try {
                empIdFilter = Integer.parseInt(parts[0].trim());
            } catch (NumberFormatException ignored) {}
        }

        String st = statusFilter.getSelectedItem().toString();
        loadLeaves(empIdFilter, st);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnApprove) {
            updateLeaveStatus("APPROVED");
        } else if (src == btnReject) {
            updateLeaveStatus("REJECTED");
        } else if (src == btnFilter) {
            handleFilter();
        } else if (src == btnRefresh) {
            empSelector.setSelectedIndex(0);
            statusFilter.setSelectedIndex(0);
            loadLeaves(null, null);
        }
    }
}
