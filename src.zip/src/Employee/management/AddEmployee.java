package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddEmployee extends JFrame implements ActionListener {

    JTextField tEmpCode, tName, tDept, tDesignation, tSalary, tDOJ, tPhone, tEmail;
    JComboBox<String> statusCombo;
    JButton btnSave, btnClear, btnClose;

    public AddEmployee() {
        setTitle("Add Employee");
        setLayout(null);
        setSize(600, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(new Color(245, 247, 250));

        // Header panel
        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 600, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Add New Employee");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(180, 20, 300, 30);
        header.add(heading);

        add(header);

        int labelX = 40;
        int fieldX = 160;
        int y = 90;
        int gap = 35;

        // Emp Code (auto)
        JLabel lCode = new JLabel("Emp Code:");
        lCode.setBounds(labelX, y, 120, 25);
        add(lCode);

        tEmpCode = new JTextField();
        tEmpCode.setBounds(fieldX, y, 160, 25);
        tEmpCode.setEditable(false);
        add(tEmpCode);
        y += gap;

        // Name
        JLabel lName = new JLabel("Name:");
        lName.setBounds(labelX, y, 120, 25);
        add(lName);

        tName = new JTextField();
        tName.setBounds(fieldX, y, 360, 25);
        add(tName);
        y += gap;

        // Department
        JLabel lDept = new JLabel("Department:");
        lDept.setBounds(labelX, y, 120, 25);
        add(lDept);

        tDept = new JTextField();
        tDept.setBounds(fieldX, y, 200, 25);
        add(tDept);
        y += gap;

        // Designation
        JLabel lDesig = new JLabel("Designation:");
        lDesig.setBounds(labelX, y, 120, 25);
        add(lDesig);

        tDesignation = new JTextField();
        tDesignation.setBounds(fieldX, y, 200, 25);
        add(tDesignation);
        y += gap;

        // Salary
        JLabel lSalary = new JLabel("Salary:");
        lSalary.setBounds(labelX, y, 120, 25);
        add(lSalary);

        tSalary = new JTextField();
        tSalary.setBounds(fieldX, y, 160, 25);
        add(tSalary);
        y += gap;

        // Date of Joining
        JLabel lDOJ = new JLabel("Date of Joining:");
        lDOJ.setBounds(labelX, y, 120, 25);
        add(lDOJ);

        tDOJ = new JTextField("2025-01-01"); // yyyy-MM-dd
        tDOJ.setBounds(fieldX, y, 160, 25);
        add(tDOJ);
        y += gap;

        // Phone
        JLabel lPhone = new JLabel("Phone:");
        lPhone.setBounds(labelX, y, 120, 25);
        add(lPhone);

        tPhone = new JTextField();
        tPhone.setBounds(fieldX, y, 200, 25);
        add(tPhone);
        y += gap;

        // Email
        JLabel lEmail = new JLabel("Email:");
        lEmail.setBounds(labelX, y, 120, 25);
        add(lEmail);

        tEmail = new JTextField();
        tEmail.setBounds(fieldX, y, 260, 25);
        add(tEmail);
        y += gap;

        // Status
        JLabel lStatus = new JLabel("Status:");
        lStatus.setBounds(labelX, y, 120, 25);
        add(lStatus);

        statusCombo = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});
        statusCombo.setBounds(fieldX, y, 160, 25);
        add(statusCombo);

        // Buttons
        btnSave = createButton("Save");
        btnSave.setBounds(120, 380, 100, 30);
        btnSave.addActionListener(this);
        add(btnSave);

        btnClear = createButton("Clear");
        btnClear.setBounds(240, 380, 100, 30);
        btnClear.addActionListener(e -> clearForm());
        add(btnClear);

        btnClose = createButton("Close");
        btnClose.setBounds(360, 380, 100, 30);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        // Generate first code
        tEmpCode.setText(generateNextEmpCode());
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(25, 118, 210));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    /**
     * Auto-generate next Emp Code: EMP0001, EMP0002, ...
     */
    private String generateNextEmpCode() {
        String prefix = "EMP";
        int nextNum = 1;

        String sql = "SELECT MAX(CAST(SUBSTRING(emp_code,4) AS UNSIGNED)) AS max_num FROM employees";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                int max = rs.getInt("max_num");
                if (!rs.wasNull()) {
                    nextNum = max + 1;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return String.format(prefix + "%04d", nextNum); // EMP0001, EMP0002...
    }

    private void clearForm() {
        tName.setText("");
        tDept.setText("");
        tDesignation.setText("");
        tSalary.setText("");
        tDOJ.setText("2025-01-01");
        tPhone.setText("");
        tEmail.setText("");
        statusCombo.setSelectedItem("ACTIVE");

        // Also prepare next emp code
        tEmpCode.setText(generateNextEmpCode());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        saveEmployee();
    }

    private void saveEmployee() {
        String empCode = tEmpCode.getText().trim();
        String name = tName.getText().trim();
        String dept = tDept.getText().trim();
        String desig = tDesignation.getText().trim();
        String salaryStr = tSalary.getText().trim();
        String dojStr = tDOJ.getText().trim();  // expected format yyyy-MM-dd
        String phone = tPhone.getText().trim();
        String email = tEmail.getText().trim();
        String status = statusCombo.getSelectedItem().toString();

        if (name.isEmpty() || dept.isEmpty() || desig.isEmpty() ||
                salaryStr.isEmpty() || dojStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all required fields");
            return;
        }

        double salary;
        try {
            salary = Double.parseDouble(salaryStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid salary amount");
            return;
        }

        java.sql.Date doj;
        try {
            doj = java.sql.Date.valueOf(dojStr); // yyyy-MM-dd
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use yyyy-MM-dd");
            return;
        }

        String sqlEmp = "INSERT INTO employees " +
                "(emp_code, name, department, designation, salary, doj, phone, email, status) " +
                "VALUES (?,?,?,?,?,?,?,?,?)";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sqlEmp, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, empCode);
            ps.setString(2, name);
            ps.setString(3, dept);
            ps.setString(4, desig);
            ps.setDouble(5, salary);
            ps.setDate(6, doj);
            ps.setString(7, phone);
            ps.setString(8, email);
            ps.setString(9, status);

            ps.executeUpdate();

            // Get generated employee id
            int employeeId = -1;
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    employeeId = keys.getInt(1);
                }
            }

            // Create login for this employee
            if (employeeId != -1) {
                String sqlUser = "INSERT INTO users (username, password, role, employee_id) " +
                        "VALUES (?,?,?,?)";

                try (PreparedStatement psUser = con.prepareStatement(sqlUser)) {
                    psUser.setString(1, empCode);     // username = EMPxxxx
                    psUser.setString(2, "123456");    // default password
                    psUser.setString(3, "EMPLOYEE");  // role
                    psUser.setInt(4, employeeId);     // FK
                    psUser.executeUpdate();
                }
            }

            JOptionPane.showMessageDialog(this,
                    "Employee added successfully.\n\nUsername: " + empCode + "\nPassword: 123456");

            clearForm();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving employee: " + ex.getMessage());
        }
    }
}
