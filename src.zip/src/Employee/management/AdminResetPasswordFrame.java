package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminResetPasswordFrame extends JFrame implements ActionListener {

    JComboBox<String> empSelector;
    JPasswordField tNew, tConfirm;
    JButton btnUpdate, btnClose;

    public AdminResetPasswordFrame() {
        setTitle("Reset Employee Password");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JLabel heading = new JLabel("Reset Employee Password");
        heading.setFont(new Font("SansSerif", Font.BOLD, 18));
        heading.setBounds(80, 15, 280, 30);
        add(heading);

        JLabel lEmp = new JLabel("Select Employee:");
        lEmp.setBounds(30, 60, 120, 25);
        add(lEmp);

        empSelector = new JComboBox<>();
        empSelector.setBounds(150, 60, 250, 25);
        add(empSelector);

        JLabel lNew = new JLabel("New Password:");
        lNew.setBounds(30, 100, 120, 25);
        add(lNew);

        tNew = new JPasswordField();
        tNew.setBounds(150, 100, 250, 25);
        add(tNew);

        JLabel lConfirm = new JLabel("Confirm Password:");
        lConfirm.setBounds(30, 140, 120, 25);
        add(lConfirm);

        tConfirm = new JPasswordField();
        tConfirm.setBounds(150, 140, 250, 25);
        add(tConfirm);

        btnUpdate = new JButton("Update");
        btnUpdate.setBounds(120, 190, 100, 30);
        btnUpdate.setBackground(new Color(25, 118, 210));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFocusPainted(false);
        btnUpdate.addActionListener(this);
        add(btnUpdate);

        btnClose = new JButton("Close");
        btnClose.setBounds(240, 190, 100, 30);
        btnClose.setBackground(new Color(25, 118, 210));
        btnClose.setForeground(Color.WHITE);
        btnClose.setFocusPainted(false);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(450, 280);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        loadEmployees();
    }

    private void loadEmployees() {
        empSelector.removeAllItems();
        empSelector.addItem("Select Employee");

        String sql = "SELECT e.id, e.emp_code, e.name " +
                "FROM employees e " +
                "JOIN users u ON e.id = u.employee_id " +
                "WHERE u.role='EMPLOYEE' " +
                "ORDER BY e.emp_code";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String code = rs.getString("emp_code");
                String name = rs.getString("name");
                empSelector.addItem(id + " - " + code + " - " + name);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            resetPassword();
        }
    }

    private void resetPassword() {
        String sel = (String) empSelector.getSelectedItem();
        if (sel == null || sel.equals("Select Employee")) {
            JOptionPane.showMessageDialog(this, "Please select an employee");
            return;
        }

        String newPass = new String(tNew.getPassword());
        String confirmPass = new String(tConfirm.getPassword());

        if (newPass.isEmpty() || confirmPass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter new password and confirm it");
            return;
        }

        if (!newPass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(this, "New password and confirm password do not match");
            return;
        }

        // parse employee id
        int employeeId;
        try {
            employeeId = Integer.parseInt(sel.split(" - ")[0]);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid employee selection");
            return;
        }

        String sql = "UPDATE users SET password=? WHERE employee_id=? AND role='EMPLOYEE'";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newPass);
            ps.setInt(2, employeeId);

            int updated = ps.executeUpdate();
            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "Password updated successfully");
                tNew.setText("");
                tConfirm.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "No user found for this employee");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating password: " + ex.getMessage());
        }
    }
}
