package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Splash extends JWindow {

    JProgressBar progressBar;
    Timer timer;
    int value = 0;

    public Splash() {
        // Window size & center
        setSize(600, 350);
        setLocationRelativeTo(null);

        // Main panel
        JPanel main = new JPanel();
        main.setLayout(null);
        main.setBackground(new Color(236, 239, 241));
        add(main);

        // Gradient top band (header)
        JPanel top = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(21, 101, 192),
                        getWidth(), getHeight(), new Color(66, 165, 245)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        top.setBounds(0, 0, 600, 120);
        top.setLayout(null);
        main.add(top);

        JLabel title = new JLabel("Employee Management System");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setBounds(120, 25, 400, 30);
        top.add(title);

        JLabel sub = new JLabel("Minor Project", SwingConstants.LEFT);
        sub.setForeground(Color.WHITE);
        sub.setFont(new Font("SansSerif", Font.PLAIN, 14));
        sub.setBounds(120, 60, 300, 20);
        top.add(sub);

        // BOLD College + 5 Names (Centered)
        JLabel college = new JLabel(
                "<html><center>"
                        + "<b>Amity University</b><br><br>"
                        + "<b>Md Wasim Khan</b><br>"
                        + "<b>Harsh Aditya Singh</b><br>"
                        + "<b>Anshu kumar gupta</b><br>"
                        + "<b>Abhishek Singh</b><br>"
                        + "<b>Shiv Kumar</b>"
                        + "</center></html>",
                SwingConstants.CENTER
        );
        college.setBounds(50, 130, 500, 140);
        college.setFont(new Font("SansSerif", Font.PLAIN, 15));
        college.setForeground(new Color(55, 71, 79));
        main.add(college);

        // Optional illustration
        try {
            ImageIcon icon = new ImageIcon("images/admin.png");
            Image img = icon.getImage().getScaledInstance(120, 90, Image.SCALE_SMOOTH);
            JLabel imgLabel = new JLabel(new ImageIcon(img));
            imgLabel.setBounds(240, 200, 120, 90);
            // main.add(imgLabel); // Remove comment if you want the image
        } catch (Exception ex) {}

        // Loading text
        JLabel loading = new JLabel("Loading, please wait...");
        loading.setBounds(220, 260, 200, 20);
        loading.setFont(new Font("SansSerif", Font.PLAIN, 12));
        loading.setForeground(new Color(55, 71, 79));
        main.add(loading);

        // Progress bar
        progressBar = new JProgressBar();
        progressBar.setBounds(100, 285, 400, 20);
        progressBar.setMinimum(0);
        progressBar.setMaximum(100);
        progressBar.setStringPainted(true);
        main.add(progressBar);

        // Timer
        timer = new Timer(40, e -> {
            value++;
            progressBar.setValue(value);
            if (value >= 100) {
                timer.stop();
                openLogin();
            }
        });

        setVisible(true);
        timer.start();
    }

    private void openLogin() {
        dispose();
        new Login().setVisible(true);
    }
}
