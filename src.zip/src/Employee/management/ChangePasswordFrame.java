package Employee.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ChangePasswordFrame extends JFrame implements ActionListener {

    int employeeId;
    JPasswordField tOld, tNew, tConfirm;
    JButton btnChange, btnClose;

    public ChangePasswordFrame(int employeeId) {
        this.employeeId = employeeId;

        setTitle("Change Password");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 450, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Change Password");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 20));
        heading.setBounds(140, 20, 200, 30);
        header.add(heading);
        add(header);

        JLabel lOld = new JLabel("Old Password:");
        lOld.setBounds(40, 90, 120, 25);
        add(lOld);

        tOld = new JPasswordField();
        tOld.setBounds(170, 90, 200, 25);
        add(tOld);

        JLabel lNew = new JLabel("New Password:");
        lNew.setBounds(40, 130, 120, 25);
        add(lNew);

        tNew = new JPasswordField();
        tNew.setBounds(170, 130, 200, 25);
        add(tNew);

        JLabel lConfirm = new JLabel("Confirm Password:");
        lConfirm.setBounds(40, 170, 120, 25);
        add(lConfirm);

        tConfirm = new JPasswordField();
        tConfirm.setBounds(170, 170, 200, 25);
        add(tConfirm);

        btnChange = new JButton("Change");
        btnChange.setBounds(110, 220, 100, 30);
        btnChange.setBackground(new Color(25, 118, 210));
        btnChange.setForeground(Color.WHITE);
        btnChange.setFocusPainted(false);
        btnChange.addActionListener(this);
        add(btnChange);

        btnClose = new JButton("Close");
        btnClose.setBounds(230, 220, 100, 30);
        btnClose.setBackground(new Color(25, 118, 210));
        btnClose.setForeground(Color.WHITE);
        btnClose.setFocusPainted(false);
        btnClose.addActionListener(e -> dispose());
        add(btnClose);

        setSize(450, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        changePassword();
    }

    private void changePassword() {
        String oldPass = new String(tOld.getPassword());
        String newPass = new String(tNew.getPassword());
        String confirmPass = new String(tConfirm.getPassword());

        if (oldPass.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required");
            return;
        }

        if (!newPass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(this, "New password and confirm password do not match");
            return;
        }

        String sqlCheck = "SELECT password FROM users WHERE employee_id=? AND role='EMPLOYEE'";
        String sqlUpdate = "UPDATE users SET password=? WHERE employee_id=? AND role='EMPLOYEE'";

        try (Connection con = conn.getConnection();
             PreparedStatement psCheck = con.prepareStatement(sqlCheck)) {

            psCheck.setInt(1, employeeId);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
                String dbPass = rs.getString("password");

                if (!dbPass.equals(oldPass)) {
                    JOptionPane.showMessageDialog(this, "Old password is incorrect");
                    return;
                }

                try (PreparedStatement psUpd = con.prepareStatement(sqlUpdate)) {
                    psUpd.setString(1, newPass);
                    psUpd.setInt(2, employeeId);
                    psUpd.executeUpdate();
                }

                JOptionPane.showMessageDialog(this, "Password updated successfully");
                dispose();

            } else {
                JOptionPane.showMessageDialog(this, "User not found for this employee");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating password: " + ex.getMessage());
        }
    }
}
