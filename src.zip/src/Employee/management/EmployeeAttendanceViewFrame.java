package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EmployeeAttendanceViewFrame extends JFrame {

    int employeeId;
    JTable table;
    DefaultTableModel model;

    public EmployeeAttendanceViewFrame(int employeeId) {
        this.employeeId = employeeId;

        setTitle("My Attendance");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(21, 101, 192));
        header.setBounds(0, 0, 750, 70);
        header.setLayout(null);

        JLabel heading = new JLabel("Attendance Overview");
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("SansSerif", Font.BOLD, 22));
        heading.setBounds(250, 20, 300, 30);
        header.add(heading);
        add(header);

        String[] cols = {"Date", "Status", "Check In", "Check Out"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(22);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 90, 700, 300);
        add(sp);

        loadAttendance();

        setSize(750, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private void loadAttendance() {
        model.setRowCount(0);

        String sql = "SELECT date, status, check_in, check_out FROM attendance WHERE employee_id=? ORDER BY date DESC";

        try (Connection con = conn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("date"),
                        rs.getString("status"),
                        rs.getString("check_in"),
                        rs.getString("check_out")
                });
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
