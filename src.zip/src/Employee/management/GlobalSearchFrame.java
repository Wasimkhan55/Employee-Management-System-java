package Employee.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GlobalSearchFrame extends JFrame {

    JTextField tSearch;
    JComboBox<String> typeCombo;
    JTable table;
    DefaultTableModel model;

    public GlobalSearchFrame() {
        setTitle("Global Search");
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        JLabel l1 = new JLabel("Search:");
        l1.setBounds(20, 20, 60, 25);
        add(l1);

        tSearch = new JTextField();
        tSearch.setBounds(80, 20, 240, 25);
        add(tSearch);

        typeCombo = new JComboBox<>(new String[]{
                "Employees", "Attendance", "Leaves"
        });
        typeCombo.setBounds(340, 20, 120, 25);
        add(typeCombo);

        JButton btnGo = new JButton("Search");
        btnGo.setBounds(470, 20, 90, 25);
        btnGo.setBackground(new Color(25, 118, 210));
        btnGo.setForeground(Color.WHITE);
        btnGo.addActionListener(e -> doSearch());
        add(btnGo);

        model = new DefaultTableModel();
        table = new JTable(model);
        table.setRowHeight(22);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 60, 540, 280);
        add(sp);

        setSize(600, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private void doSearch() {
        String text = tSearch.getText().trim();
        String type = typeCombo.getSelectedItem().toString();

        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter something to search");
            return;
        }

        try (Connection con = conn.getConnection()) {

            if (type.equals("Employees")) {
                model.setColumnIdentifiers(new String[]{"Emp Code", "Name", "Dept", "Desig", "Status"});
                model.setRowCount(0);

                String sql = "SELECT emp_code, name, department, designation, status " +
                        "FROM employees WHERE emp_code LIKE ? OR name LIKE ? OR department LIKE ?";

                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    String pattern = "%" + text + "%";
                    ps.setString(1, pattern);
                    ps.setString(2, pattern);
                    ps.setString(3, pattern);
                    ResultSet rs = ps.executeQuery();

                    while (rs.next()) {
                        model.addRow(new Object[]{
                                rs.getString(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4),
                                rs.getString(5)
                        });
                    }
                }
            } else if (type.equals("Attendance")) {
                model.setColumnIdentifiers(new String[]{"Date", "Emp Code", "Name", "Status"});
                model.setRowCount(0);

                String sql =
                        "SELECT a.date, e.emp_code, e.name, a.status " +
                                "FROM attendance a JOIN employees e ON a.employee_id=e.id " +
                                "WHERE e.emp_code LIKE ? OR e.name LIKE ? OR a.date LIKE ?";

                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    String pattern = "%" + text + "%";
                    ps.setString(1, pattern);
                    ps.setString(2, pattern);
                    ps.setString(3, pattern);
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        model.addRow(new Object[]{
                                rs.getDate(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4)
                        });
                    }
                }
            } else if (type.equals("Leaves")) {
                model.setColumnIdentifiers(new String[]{"Emp Code", "Name", "Type", "From", "To", "Status"});
                model.setRowCount(0);

                String sql =
                        "SELECT e.emp_code, e.name, l.leave_type, l.start_date, l.end_date, l.status " +
                                "FROM leave_applications l JOIN employees e ON l.employee_id=e.id " +
                                "WHERE e.emp_code LIKE ? OR e.name LIKE ? OR l.leave_type LIKE ?";

                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    String pattern = "%" + text + "%";
                    ps.setString(1, pattern);
                    ps.setString(2, pattern);
                    ps.setString(3, pattern);
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        model.addRow(new Object[]{
                                rs.getString(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4),
                                rs.getString(5),
                                rs.getString(6)
                        });
                    }
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error searching: " + ex.getMessage());
        }
    }
}
