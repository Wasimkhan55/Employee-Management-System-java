package Employee.management;

public class MainApp {
    public static void main(String[] args) {
        // Start splash screen first
        new Splash();
    }
}
